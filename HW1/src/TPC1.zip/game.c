#include <stdlib.h>
#include "config.h"
#include "game.h"
#include <assert.h>
#include <string.h>
/*
'#'
*/
const int ALIVE = 35;
/*
'.'
*/
const int DEAD = 46;
/*
':'
*/
const int DIVIDER1 = 58;

/*
*/
const int UNDERPOPULATED = 2;
const int OVERPOPULATION = 3;
const int REPRODUCTION = 3;
const int LIVE1 = 2;
const int LIVE2 = 3;

/**
 * Frees memory allocated to a Game structure.
 *
 * @param game Pointer to be freed.
 */
void game_free(Game *game)
{
  assert(game != NULL);
  if(game->board != NULL)
    free(game->board);
  free(game);
}

/**
 * Checks whether a given board position is in an alive state.
 *
 * @param game Pointer to a Game structure.
 * @param row  The row number.
 * @param col  The column number.
 *
 * @retval 0 The position is in a dead state.
 * @retval 1 The position is in an alive state.
 */
int game_cell_is_alive(Game *game, size_t row, size_t col)
{
	int pos;

	pos = row * game->cols + col;

	assert(game != NULL);
	assert(game->board != NULL);

	return game->board[pos] == ALIVE;
}

/**
 * Checks whether a given board position is in a dead state.
 *
 * @param game Pointer to a Game structure.
 * @param row  The row number.
 * @param col  The column number.
 *
 * @retval 0 The position is in an alive state.
 * @retval 1 The position is in a dead state.
 */
int game_cell_is_dead(Game *game, size_t row, size_t col)
{
	int pos;
	pos = row * game->cols + col;

	assert(game != NULL);
	assert(game->board != NULL);

	return game->board[pos] == DEAD;
}

/**
 * Allocates memory for a new Game structure.
 *
 * @return A new Game pointer.
 */
Game *game_new(void)
{
		Game* game = (Game *)malloc(sizeof(Game));
		game->board = NULL;
		game->rows = 0;
		game->cols = 0;

		return game;
}

/**
 * Parses a board file into an internal representation.
 *
 * Currently, this function only parses the custom file format
 * used by the program, but it should be trivial to add other
 * file formats.
 *
 * @param game Pointer to a Game structure.
 * @param config Pointer to a GameConfig structure.
 *
 * @retval 0 The board file was parsed correctly.
 * @retval 1 The board file could not be parsed.
 */
int game_parse_board(Game *game, GameConfig *config)
{
	int i, c, foundDivider, boardPos, boardSize;
	const int MAX_READ = 1024;
	char buff[1024];
	char r[1024];

	assert(game != NULL);
	assert(config != NULL);
	assert(config->input_file != NULL);

	fgets(buff, MAX_READ, config->input_file);
	for(i = 0, foundDivider = -1; i < MAX_READ && buff[i] != '\n'; i++)
	{
		if(foundDivider > -1)
		{
			r[foundDivider++] = buff[i];
		}
		else
		{
			if(buff[i] == DIVIDER1)
					foundDivider++;
		}
	}
	r[foundDivider++] = '\0';

	game->rows = atoi(r);

	fgets(buff, MAX_READ, config->input_file);
	for(i = 0, foundDivider = -1; i < MAX_READ && buff[i] != '\n'; i++)
	{

		if(foundDivider > -1)
		{
			r[foundDivider++] = buff[i];
		}
		else
		{
			if(buff[i] == DIVIDER1)
					foundDivider++;
		}
	}
	r[foundDivider++] = '\0';

	game->cols = atoi(r);

	boardSize = sizeof(char) * ((game->rows * game->cols) + 1);
	boardPos = 0;

	game->board = (char *)malloc(boardSize);

	while (fgets(buff, MAX_READ, config->input_file) != NULL && boardPos < boardSize)
	{
		for (i = 0; i < MAX_READ && buff[i] != '\n' && buff[i] != '\0'; i++)
		{
			c = buff[i];
			if (c == ALIVE)
				game->board[boardPos++] = ALIVE;
			else if (c == DEAD)
				game->board[boardPos++] = DEAD;
		}
	}
	game->board[boardPos] = '\0';

	fclose(config->input_file);
	config->input_file = NULL;
	return 1;
}

/**
 * Prints the current state of the board.
 *
 * @param game Pointer to a Game structure.
 */
void game_print_board(Game *game)
{
	int r, boardPos, boardSize, printSize;
	char * board = NULL;

	assert(game != NULL);
	assert(game->board != NULL);

	boardSize = game->rows * game->cols;
	printSize = game->rows * (game->cols + 1) * sizeof(char) + 1;
	board = (char *) malloc(printSize);

	for(r = 0, boardPos = 0; r < boardSize; r++)
	{
			board[boardPos++] = game->board[r];
			if((r + 1) % game->cols == 0)
				board[boardPos++] = '\n';
	}
	board[boardPos] = '\0';
	printf("%s", board);
}

/**
 * Sets a specific position in the board to an alive state.
 *
 * @param game Pointer to a Game structure.
 * @param row  The row number.
 * @param col  The column number.
 */
void game_cell_set_alive(Game *game, size_t row, size_t col)
{
	int pos;
	pos = row * game->cols + col;

	assert(game != NULL);
	assert(game->board != NULL);

	game->board[pos] = ALIVE;
}

/**
 * Sets a specific position in the board to a dead state.
 *
 * @param game Pointer to a Game structure.
 * @param row  The row number.
 * @param col  The column number.
 */
void game_cell_set_dead(Game *game, size_t row, size_t col)
{
	int pos;
	pos = row * game->cols + col;

	assert(game != NULL);
	assert(game->board != NULL);

	game->board[pos] = DEAD;
}

/**
 * Advances the cell board to a new generation (causes a 'tick').
 *
 * @param game Pointer to a Game structure.
 *
 * @retval 0 The tick has happened successfully.
 * @retval 1 The tick could not happen correctly.
 */
int game_tick(Game *game)
{
	int boardSize;
	int row, col, i;
	int r, c;
	int top, left, right, bottom, topleft, topright, bottomleft, bottomright;
	int tmp, tmp2, boardALLOC;
	int changed = 0;
	Game * tmpGame;

	tmpGame = game_new();
	boardSize = game->rows * game->cols;
	boardALLOC = boardSize * sizeof(char) + 1;
	tmpGame->rows = game->rows;
	tmpGame->cols = game->cols;
	tmpGame->board = (char *)malloc(boardALLOC);

	strcpy(tmpGame->board, game->board);

	r = game->rows - 1;
	c = game->cols;
	i = 0;
	for(row = 0; row < game->rows; row++)
	{
		for(col = 0; col < game->cols; col++, i++)
		{/*
			top cell
			*/
			tmp = row - 1;
			if(tmp == -1)
				tmp = r;
			top = game_cell_is_alive(game, tmp, col);
			/*
			right cell
			*/
			tmp = col + 1;
			if(tmp == c)
				tmp = 0;
			right = game_cell_is_alive(game, row, tmp);
			/*
			left cell
			*/
			tmp = col - 1;
			if(tmp == -1)
				tmp = c - 1;
			left = game_cell_is_alive(game, row, tmp);
			/*
			bottom cell
			*/
			tmp = row + 1;
			if(tmp > r)
				tmp = 0;
			bottom = game_cell_is_alive(game, tmp, col);
			/*
			upper left cell
			*/
			tmp = row - 1;
			if(tmp == -1)
				tmp = r;
			tmp2 = col - 1;
			if(tmp2 == -1)
				tmp2 = c - 1;
			topleft = game_cell_is_alive(game, tmp, tmp2);
			/*
			upper right cell
			*/
			tmp2 = col + 1;
			if(tmp2 == c)
				tmp2 = 0;
			topright = game_cell_is_alive(game, tmp, tmp2);
			/*
			bottom left cell
			*/
			tmp = row + 1;
			if(tmp > r)
				tmp = 0;
			tmp2 = col - 1;
			if(tmp2 == -1)
				tmp2 = c - 1;
			bottomleft = game_cell_is_alive(game, tmp, tmp2);
			/*
			bottom right cell
			*/
			tmp2 = col + 1;
			if(tmp2 == c)
				tmp2 = 0;
			bottomright = game_cell_is_alive(game, tmp, tmp2);

			tmp = top + right + bottom + left + topleft + topright + bottomleft + bottomright;

			if(game_cell_is_alive(game, row, col))
			{
				if(tmp > OVERPOPULATION ||  tmp < UNDERPOPULATED)
					game_cell_set_dead(tmpGame, row, col);
			}

			else if(game_cell_is_dead(game, row, col))
			{
				if(tmp == REPRODUCTION)
					game_cell_set_alive(tmpGame, row, col);
			}
			if(game->board[i] != tmpGame->board[i])
				changed = 1;
		}
	}
	tmpGame->board[i] = '\0';
	strcpy(game->board, tmpGame->board);
	game_free(tmpGame);

	return changed;
}
