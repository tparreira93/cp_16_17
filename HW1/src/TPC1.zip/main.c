#include "main.h"
#include <assert.h>

int const NO_FILE = -1;
char NO_FILE_STR[] = "File not found!";

int main(int argc, char *argv[])
{
	GameConfig* config = game_config_new_from_cli(argc, argv);
	Game * game;
	int file_loaded = 0;
	/*config->input_file = fopen("D:\\Universidade\\CP\\glife\\tests\\3.in", "r");
	config->generations = 1000000;
	config->debug = 1;
	config->silent = 0;*/
	if(config->input_file != NULL)
		file_loaded = 1;
	/*printf("Debug = %d\nSilent = %d\nGenerations = %lu\nInput File loaded = %d\n", config->debug, config->silent, config->generations, file_loaded);*/

	if(!file_loaded)
	{
		/*printf("%s\n", NO_FILE_STR);*/
		return -1;
	}

	game = game_new();
	game_parse_board(game, config);

	/*printf("\n");
	printf("Rows: %lu\n", game->rows);
	printf("Cols: %lu\n", game->cols);
	printf("Board:\n");
	game_print_board(game);*/
	run(game, config);

	game_config_free(config);
	game_free(game);
	return 0;
}

void run(Game * game, GameConfig * config)
{
	int ticks, changed = 0;
	ticks = 1;

	assert(game != NULL);
	assert(config != NULL);

	do {
		if(ticks <= config->generations)
			changed = game_tick(game);
		else
			changed = 0;

		if(config->debug && (changed || ticks == 1))
		{
			printf("\nGeneration %d\n", ticks);
			game_print_board(game);
		}
		ticks++;
	} while(changed);

}
