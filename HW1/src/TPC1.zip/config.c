#include "config.h"
#include <stdio.h>
#include <unistd.h>
#include <getopt.h>
#include <string.h>
#include <ctype.h>

char const * valid_flags = "n::ds";
int const default_generations = 20;

void game_config_free(GameConfig *config)
{
	if(config->input_file != NULL)
		fclose(config->input_file);
	free(config);
}

size_t game_config_get_generations(GameConfig *config)
{
	if(config == NULL)
		return 0;

	return config->generations;
}

void init_config(GameConfig* config)
{
	if(config != NULL)
	{
		config->debug = 0;
		config->silent = 0;
		config->input_file = NULL;
		config->generations = default_generations;
	}
}

GameConfig *game_config_new_from_cli(int argc, char *argv[])
{
	int option = 0, ind = 0;
	GameConfig* config = (GameConfig *) malloc(sizeof(GameConfig));
	init_config(config);

	while ((option = getopt(argc, argv, valid_flags)) != -1) {
		switch (option) {
		case 'n':
			ind = optind;
			if(ind < argc && ind >= 0)
			{
				if(isdigit(argv[ind][0]))
				{
					config->generations = atoi(argv[ind]);
					optind++;
				}
			}
			break;
		case 's':
			config->silent = 1;
			break;
		case 'd':
			config->debug = 1;
			break;
		}
	}

	if(optind < argc)
	{
		FILE * f = fopen(argv[optind], "r");
		if(f != NULL)
			config->input_file = f;
	}

	return config;
}
