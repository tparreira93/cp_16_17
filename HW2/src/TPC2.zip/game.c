#include <stdlib.h>
#include "config.h"
#include "game.h"
#include <assert.h>
#include <string.h>
#include "cilk/cilk.h"
#include <cilk/cilk_api.h>

/*
'#'
*/
const int ALIVE = 35;
/*
'.'
*/
const int DEAD = 46;
/*
':'
*/
const int DIVIDER1 = 58;

/*
*/
const int UNDERPOPULATED = 2;
const int OVERPOPULATION = 3;
const int REPRODUCTION = 3;
const int LIVE1 = 2;
const int LIVE2 = 3;

int workers = 1;

/**
* Frees memory allocated to a Game structure.
*
* @param game Pointer to be freed.
*/
void game_free(Game *game)
{
	assert(game != NULL);
	if (game->board != NULL)
		free(game->board);
	free(game);
}

/**
* Checks whether a given board position is in an alive state.
*
* @param game Pointer to a Game structure.
* @param row  The row number.
* @param col  The column number.
*
* @retval 0 The position is in a dead state.
* @retval 1 The position is in an alive state.
*/
int game_cell_is_alive(Game *game, size_t row, size_t col)
{
	int pos;

	pos = row * game->cols + col;

	assert(game != NULL);
	assert(game->board != NULL);

	return game->board[pos] == ALIVE;
}

/**
* Checks whether a given board position is in a dead state.
*
* @param game Pointer to a Game structure.
* @param row  The row number.
* @param col  The column number.
*
* @retval 0 The position is in an alive state.
* @retval 1 The position is in a dead state.
*/
int game_cell_is_dead(Game *game, size_t row, size_t col)
{
	int pos;
	pos = row * game->cols + col;

	assert(game != NULL);
	assert(game->board != NULL);

	return game->board[pos] == DEAD;
}

/**
* Allocates memory for a new Game structure.
*
* @return A new Game pointer.
*/
Game *game_new(void)
{
	Game* game = (Game *)malloc(sizeof(Game));
	game->board = NULL;
	game->rows = 0;
	game->cols = 0;

	return game;
}

/**
* Parses a board file into an internal representation.
*
* Currently, this function only parses the custom file format
* used by the program, but it should be trivial to add other
* file formats.
*
* @param game Pointer to a Game structure.
* @param config Pointer to a GameConfig structure.
*
* @retval 0 The board file was parsed correctly.
* @retval 1 The board file could not be parsed.
*/
int game_parse_board(Game *game, GameConfig *config)
{
	int i, c, foundDivider, boardPos, boardSize;
	const int MAX_READ = 2048;
	char buff[1024];
	char r[1024];

	assert(game != NULL);
	assert(config != NULL);
	assert(config->input_file != NULL);

	workers = config->workers;

	fgets(buff, MAX_READ, config->input_file);
	for (i = 0, foundDivider = -1; i < MAX_READ && buff[i] != '\n'; i++)
	{
		if (foundDivider > -1)
		{
			r[foundDivider++] = buff[i];
		}
		else
		{
			if (buff[i] == DIVIDER1)
				foundDivider++;
		}
	}
	r[foundDivider++] = '\0';

	game->rows = atoi(r);

	fgets(buff, MAX_READ, config->input_file);
	for (i = 0, foundDivider = -1; i < MAX_READ && buff[i] != '\n'; i++)
	{

		if (foundDivider > -1)
		{
			r[foundDivider++] = buff[i];
		}
		else
		{
			if (buff[i] == DIVIDER1)
				foundDivider++;
		}
	}
	r[foundDivider++] = '\0';

	game->cols = atoi(r);

	boardSize = sizeof(char) * ((game->rows * game->cols) + 1);
	boardPos = 0;

	game->board = (char *)malloc(boardSize);

	while (fgets(buff, MAX_READ, config->input_file) != NULL && boardPos < boardSize)
	{
		for (i = 0; i < MAX_READ && buff[i] != '\n' && buff[i] != '\0'; i++)
		{
			c = buff[i];
			if (c == ALIVE)
				game->board[boardPos++] = ALIVE;
			else if (c == DEAD)
				game->board[boardPos++] = DEAD;
		}
	}
	game->board[boardPos] = '\0';

	fclose(config->input_file);
	config->input_file = NULL;
	return 1;
}

/**
* Prints the current state of the board.
*
* @param game Pointer to a Game structure.
*/
void game_print_board(Game *game)
{
	int r, boardPos, boardSize, printSize;
	char * board = NULL;

	assert(game != NULL);
	assert(game->board != NULL);

	boardSize = game->rows * game->cols;
	printSize = game->rows * (game->cols + 1) * (sizeof(char) + 1);
	board = (char *)malloc(printSize);

	for (r = 0, boardPos = 0; r < boardSize; r++)
	{
		board[boardPos++] = game->board[r];
		if ((r + 1) % game->cols == 0)
			board[boardPos++] = '\n';
	}
	board[boardPos] = '\0';
	printf("%s", board);
}

/**
* Sets a specific position in the board to an alive state.
*
* @param game Pointer to a Game structure.
* @param row  The row number.
* @param col  The column number.
*/
void game_cell_set_alive(Game *game, size_t row, size_t col)
{
	int pos;
	pos = row * game->cols + col;

	assert(game != NULL);
	assert(game->board != NULL);

	game->board[pos] = ALIVE;
}

/**
* Sets a specific position in the board to a dead state.
*
* @param game Pointer to a Game structure.
* @param row  The row number.
* @param col  The column number.
*/
void game_cell_set_dead(Game *game, size_t row, size_t col)
{
	int pos;
	pos = row * game->cols + col;

	assert(game != NULL);
	assert(game->board != NULL);

	game->board[pos] = DEAD;
}

const int neighborhood[8][2] = {
	{ 0,   1 },
	{ 1,   1 },
	{ 1,   0 },
	{ 1,  -1 },
	{ 0,  -1 },
	{ -1, -1 },
	{ -1,  0 },
	{ -1,  1 }
};

int aliveNeighbors(Game * game, int row, int col)
{
	int sum;
	int i;
	sum = 0;

	for (i = 0; i < 8; i++)
	{
		int c = col + neighborhood[i][0];
		int r = row + neighborhood[i][1];

		if (r < 0)
			r = game->rows - 1;
		else if (r >= game->rows)
			r = 0;

		if (c < 0)
			c = game->cols - 1;
		else if (c >= game->cols)
			c = 0;

		sum += game_cell_is_alive(game, r, c);
	}

	return sum;
}

void RowComputation(Game * game, char * row, size_t row_N, size_t col_N, int * changed)
{
	int i;
	int sum;
	int idx;

	*changed = 0;

	for (i = 0; i < col_N; i++)
	{
		sum = aliveNeighbors(game, row_N, i);
		if (game_cell_is_alive(game, row_N, i))
		{
			if (sum > OVERPOPULATION || sum < UNDERPOPULATED)
			{
				row[i] = DEAD;
				*changed = 1;
			}
			else
			{
				idx = row_N * game->cols + i;
				row[i] = game->board[idx];
			}
		}

		else if (game_cell_is_dead(game, row_N, i))
		{
			if (sum == REPRODUCTION)
			{
				row[i] = ALIVE;
				*changed = 1;
			}
			else
			{
				idx = row_N * game->cols + i;
				row[i] = game->board[idx];
			}
		}
	}
}

void BoardPartComputation(Game * game, char * boardPart, size_t part_size, int * changed)
{
	int i;
	int sum;
	int r, c;
	*changed = 0;


	for (i = 0; i < part_size; i++)
	{
		r = i / game->cols;
		c = i % c;

		sum = aliveNeighbors(game, r, c);
		if (game_cell_is_alive(game, r, c))
		{
			if (sum > OVERPOPULATION || sum < UNDERPOPULATED)
			{
				boardPart[i] = DEAD;
				*changed = 1;
			}
			else
			{
				boardPart[i] = game->board[i];
			}
		}

		else if (game_cell_is_dead(game, r, c))
		{
			if (sum == REPRODUCTION)
			{
				boardPart[i] = ALIVE;
				*changed = 1;
			}
			else
			{
				boardPart[i] = game->board[i];
			}
		}
	}
}

/**
* Advances the cell board to a new generation (causes a 'tick').
*
* @param game Pointer to a Game structure.
*
* @retval 0 The tick has happened successfully.
* @retval 1 The tick could not happen correctly.
*/
int game_tick(Game *game)
{
	int c = 0;
	int row;
	int boardAllocation;
	int * changed;
	char * finalBoard;
	char * boardPart;
	int row_i;
	char wk[10];

	sprintf(wk, "%d", workers);
	__cilkrts_set_param("nworkers", wk);

	boardAllocation = sizeof(char) * ((game->rows * game->cols) + 1);
	finalBoard = (char *)malloc(boardAllocation);
	changed = (int *)malloc(sizeof(int) * game->rows);
 
	for (row = 0; row < game->rows; row++)
	{
		row_i = row * game->cols;
		boardPart = finalBoard + row_i;
		cilk_spawn RowComputation(game, boardPart, row, game->cols, &changed[row]);
		/*cilk_spawn BoardPartComputation(game, boardPart, row, &changed[row]);*/
	}
	cilk_sync;
	for(row = 0; row < game->rows; row++)
		c |= changed[row];
	row_i = game->rows * game->cols;
	finalBoard[row_i] = '\0';
	free(game->board);
	game->board = finalBoard;
	return c;
}
