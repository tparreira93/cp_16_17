#include "main.h"
#include <assert.h>

int const NO_FILE = -1;
char NO_FILE_STR[] = "File not found!";

int main(int argc, char *argv[])
{
	GameConfig* config = game_config_new_from_cli(argc, argv);
	Game * game;
	int file_loaded = 0;
	if(config->input_file != NULL)
		file_loaded = 1;

	if(!file_loaded)
	{
		return -1;
	}

	game = game_new();
	game_parse_board(game, config);
	run(game, config);

	game_config_free(config);
	game_free(game);
	return 0;
}

void run(Game * game, GameConfig * config)
{
	int ticks, changed = 0;
	ticks = 1;

	assert(game != NULL);
	assert(config != NULL);

	do {
		if(ticks <= config->generations)
			changed = game_tick(game);
		else
			changed = 0;

		if(config->debug && (changed || ticks == 1))
		{
			printf("\nGeneration %d\n", ticks);
			game_print_board(game);
		}
		ticks++;
	} while(changed);

}
