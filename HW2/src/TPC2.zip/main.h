
#include "config.h"
#include "game.h"
void run(Game * game, GameConfig * config);
