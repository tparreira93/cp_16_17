package cp.articlerep;

public class StopVar {
	public volatile boolean stop = false;
}
