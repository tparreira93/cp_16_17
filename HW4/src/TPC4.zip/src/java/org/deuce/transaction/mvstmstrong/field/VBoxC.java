package org.deuce.transaction.mvstmstrong.field;

import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public interface VBoxC extends VBox {

	void commit(char value, int txNumber);

}
