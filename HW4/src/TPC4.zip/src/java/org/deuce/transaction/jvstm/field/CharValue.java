package org.deuce.transaction.jvstm.field;

public class CharValue implements Value {
	public char value;
}
