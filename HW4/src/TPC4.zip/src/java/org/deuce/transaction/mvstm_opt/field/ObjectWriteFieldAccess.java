package org.deuce.transaction.mvstm_opt.field;

import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public class ObjectWriteFieldAccess extends WriteFieldAccess {

	public Object value;

	public void set(Object value, VBox field) {
		super.init(field);
		this.value = value;
	}
	
	@Override
	public void prepare() {
		((VBoxO)field).prepare(value);
	}

	public Object getValue() {
		return value;
	}
}
