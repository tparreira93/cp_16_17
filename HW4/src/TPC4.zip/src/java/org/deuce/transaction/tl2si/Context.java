package org.deuce.transaction.tl2si;

import java.util.concurrent.atomic.AtomicInteger;

import org.deuce.InPlaceMetadata;
import org.deuce.transaction.TransactionException;
import org.deuce.transaction.tl2.pool.Pool;
import org.deuce.transaction.tl2.pool.ResourceFactory;
import org.deuce.transaction.tl2si.field.BooleanWriteFieldAccess;
import org.deuce.transaction.tl2si.field.ByteWriteFieldAccess;
import org.deuce.transaction.tl2si.field.CharWriteFieldAccess;
import org.deuce.transaction.tl2si.field.DoubleWriteFieldAccess;
import org.deuce.transaction.tl2si.field.FloatWriteFieldAccess;
import org.deuce.transaction.tl2si.field.IntWriteFieldAccess;
import org.deuce.transaction.tl2si.field.LongWriteFieldAccess;
import org.deuce.transaction.tl2si.field.ObjectWriteFieldAccess;
import org.deuce.transaction.tl2si.field.ReadFieldAccess;
import org.deuce.transaction.tl2si.field.ShortWriteFieldAccess;
import org.deuce.transaction.tl2si.field.WriteFieldAccess;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxField;
import org.deuce.trove.TObjectProcedure;

/**
 * TL2 with in-place metadata.
 * 
 * @author Ricardo Dias, Tiago Vale <{ricardo.dias,t.vale}@campus.fct.unl.pt}>
 */
@ExcludeInternal
@InPlaceMetadata(
		fieldObjectClass = "org.deuce.transaction.tl2si.TL2Field", 
		fieldIntClass = "org.deuce.transaction.tl2si.TL2Field", 
		fieldShortClass = "org.deuce.transaction.tl2si.TL2Field", 
		fieldCharClass = "org.deuce.transaction.tl2si.TL2Field", 
		fieldByteClass = "org.deuce.transaction.tl2si.TL2Field", 
		fieldBooleanClass = "org.deuce.transaction.tl2si.TL2Field", 
		fieldFloatClass = "org.deuce.transaction.tl2si.TL2Field", 
		fieldLongClass = "org.deuce.transaction.tl2si.TL2Field", 
		fieldDoubleClass = "org.deuce.transaction.tl2si.TL2Field",

		arrayObjectClass = "org.deuce.transaction.tl2si.TL2ArrObjectField", 
		arrayIntClass = "org.deuce.transaction.tl2si.TL2ArrIntField", 
		arrayByteClass = "org.deuce.transaction.tl2si.TL2ArrByteField", 
		arrayShortClass = "org.deuce.transaction.tl2si.TL2ArrShortField", 
		arrayCharClass = "org.deuce.transaction.tl2si.TL2ArrCharField", 
		arrayBooleanClass = "org.deuce.transaction.tl2si.TL2ArrBoolField", 
		arrayFloatClass = "org.deuce.transaction.tl2si.TL2ArrFloatField", 
		arrayLongClass = "org.deuce.transaction.tl2si.TL2ArrLongField", 
		arrayDoubleClass = "org.deuce.transaction.tl2si.TL2ArrDoubleField")

final public class Context extends org.deuce.transaction.ContextMetadata {

	private static final boolean TX_LOAD_OPT = Boolean.getBoolean("org.deuce.transaction.tl2si.txload.opt");

	final static AtomicInteger clock = new AtomicInteger(0);
	
	final private WriteSet writeSet = new WriteSet();

	private ReadFieldAccess currentReadFieldAccess = new ReadFieldAccess(null, 0);

	// Marked on beforeRead, used for the double lock check
	private int localClock;
	private int lastReadLock;

	final private LockProcedure lockProcedure = new LockProcedure(this);

	final private TObjectProcedure<WriteFieldAccess> putProcedure = new TObjectProcedure<WriteFieldAccess>() {

		public boolean execute(WriteFieldAccess writeField) {
			writeField.put();
			return true;
		}

	};

	public Context() {
		this.localClock = clock.get();
	}

	public void initImpl(int atomicBlockId, String metainf) {
		this.writeSet.clear();
		this.objectPool.clear();
		this.booleanPool.clear();
		this.bytePool.clear();
		this.charPool.clear();
		this.shortPool.clear();
		this.intPool.clear();
		this.longPool.clear();
		this.floatPool.clear();
		this.doublePool.clear();
		
		this.localClock = clock.get();
	}
	
	private TObjectProcedure<WriteFieldAccess> validateProcedure = 
			new TObjectProcedure<WriteFieldAccess>() {
				
			public boolean execute(WriteFieldAccess wfa) {
				((InPlaceLock)wfa.field).checkLock2(wfa.clock);
				return true;
			}
		};

	public boolean commit() {
		if (writeSet.isEmpty()) { // if the writeSet is empty no need to lock a thing.
			return true;
		}

		try {
			// pre commit validation phase
			writeSet.forEach(lockProcedure);
			writeSet.forEach(validateProcedure);
		} catch (TransactionException exception) {
			writeSet.forEach(lockProcedure.unlockProcedure);
			return false;
		}

		// commit new values and release locks
		writeSet.forEach(putProcedure);

		lockProcedure.setAndUnlockProcedure.retrieveNewClock();
		writeSet.forEach(lockProcedure.setAndUnlockProcedure);

		lockProcedure.clear();

		return true;
	}

	public void rollback() {
	}
	

	private WriteFieldAccess onReadAccess0(TxField field) {
		ReadFieldAccess current = currentReadFieldAccess;

		// Check the read is still valid
		((InPlaceLock) field).checkLock(localClock, lastReadLock);

		// Check if it is already included in the write set
		return writeSet.contains(current);
	}

	private void addWriteAccess0(WriteFieldAccess write) {
		// Add to write set
		writeSet.put(write);
	}

	public void beforeReadAccess(TxField field) {
			currentReadFieldAccess.init(field, 0);

			// Check the read is still valid
			lastReadLock = ((InPlaceLock) field).checkLock(localClock);
	}

	public Object onReadAccess(Object value, TxField field) {
		WriteFieldAccess writeAccess = onReadAccess0(field);
		if (writeAccess == null)
			return value;

		Object r = ((ObjectWriteFieldAccess) writeAccess).getValue();

		return r;
	}

	public boolean onReadAccess(boolean value, TxField field) {
		WriteFieldAccess writeAccess = onReadAccess0(field);
		if (writeAccess == null)
			return value;

		boolean r = ((BooleanWriteFieldAccess) writeAccess).getValue();

		return r;
	}

	public byte onReadAccess(byte value, TxField field) {
		WriteFieldAccess writeAccess = onReadAccess0(field);
		if (writeAccess == null)
			return value;

		byte r = ((ByteWriteFieldAccess) writeAccess).getValue();

		return r;
	}

	public char onReadAccess(char value, TxField field) {
		WriteFieldAccess writeAccess = onReadAccess0(field);
		if (writeAccess == null)
			return value;

		char r = ((CharWriteFieldAccess) writeAccess).getValue();

		return r;
	}

	public short onReadAccess(short value, TxField field) {
		WriteFieldAccess writeAccess = onReadAccess0(field);
		if (writeAccess == null)
			return value;

		short r = ((ShortWriteFieldAccess) writeAccess).getValue();

		return r;

	}

	public int onReadAccess(int value, TxField field) {
		WriteFieldAccess writeAccess = onReadAccess0(field);
		if (writeAccess == null)
			return value;

		int r = ((IntWriteFieldAccess) writeAccess).getValue();

		return r;
	}

	public long onReadAccess(long value, TxField field) {
		WriteFieldAccess writeAccess = onReadAccess0(field);
		if (writeAccess == null)
			return value;

		long r = ((LongWriteFieldAccess) writeAccess).getValue();

		return r;
	}

	public float onReadAccess(float value, TxField field) {
		WriteFieldAccess writeAccess = onReadAccess0(field);
		if (writeAccess == null)
			return value;

		float r = ((FloatWriteFieldAccess) writeAccess).getValue();

		return r;
	}

	public double onReadAccess(double value, TxField field) {
		WriteFieldAccess writeAccess = onReadAccess0(field);
		if (writeAccess == null)
			return value;

		double r = ((DoubleWriteFieldAccess) writeAccess).getValue();

		return r;
	}

	public void onWriteAccess(Object value, TxField field) {

		ObjectWriteFieldAccess next = objectPool.getNext();
		int clock = ((InPlaceLock)field).checkLock(localClock);
		next.set(value, field, clock);
		addWriteAccess0(next);

	}

	public void onWriteAccess(boolean value, TxField field) {

		BooleanWriteFieldAccess next = booleanPool.getNext();
		int clock = ((InPlaceLock)field).checkLock(localClock);
		next.set(value, field, clock);
		addWriteAccess0(next);

	}

	public void onWriteAccess(byte value, TxField field) {

		ByteWriteFieldAccess next = bytePool.getNext();
		int clock = ((InPlaceLock)field).checkLock(localClock);
		next.set(value, field, clock);
		addWriteAccess0(next);

	}

	public void onWriteAccess(char value, TxField field) {

		CharWriteFieldAccess next = charPool.getNext();
		int clock = ((InPlaceLock)field).checkLock(localClock);
		next.set(value, field, clock);
		addWriteAccess0(next);

	}

	public void onWriteAccess(short value, TxField field) {

		ShortWriteFieldAccess next = shortPool.getNext();
		int clock = ((InPlaceLock)field).checkLock(localClock);
		next.set(value, field, clock);
		addWriteAccess0(next);

	}

	public void onWriteAccess(int value, TxField field) {

		IntWriteFieldAccess next = intPool.getNext();
		int clock = ((InPlaceLock)field).checkLock(localClock);
		next.set(value, field, clock);
		addWriteAccess0(next);

	}

	public void onWriteAccess(long value, TxField field) {

		LongWriteFieldAccess next = longPool.getNext();
		int clock = ((InPlaceLock)field).checkLock(localClock);
		next.set(value, field, clock);
		addWriteAccess0(next);

	}

	public void onWriteAccess(float value, TxField field) {

		FloatWriteFieldAccess next = floatPool.getNext();
		int clock = ((InPlaceLock)field).checkLock(localClock);
		next.set(value, field, clock);
		addWriteAccess0(next);

	}

	public void onWriteAccess(double value, TxField field) {

		DoubleWriteFieldAccess next = doublePool.getNext();
		int clock = ((InPlaceLock)field).checkLock(localClock);
		
		next.set(value, field, clock);
		addWriteAccess0(next);

	}

	private static class ObjectResourceFactory implements ResourceFactory<ObjectWriteFieldAccess> {
		public ObjectWriteFieldAccess newInstance() {
			return new ObjectWriteFieldAccess();
		}
	}

	final private Pool<ObjectWriteFieldAccess> objectPool = new Pool<ObjectWriteFieldAccess>(
			new ObjectResourceFactory());

	private static class BooleanResourceFactory implements ResourceFactory<BooleanWriteFieldAccess> {
		public BooleanWriteFieldAccess newInstance() {
			return new BooleanWriteFieldAccess();
		}
	}

	final private Pool<BooleanWriteFieldAccess> booleanPool = new Pool<BooleanWriteFieldAccess>(
			new BooleanResourceFactory());

	private static class ByteResourceFactory implements ResourceFactory<ByteWriteFieldAccess> {
		public ByteWriteFieldAccess newInstance() {
			return new ByteWriteFieldAccess();
		}
	}

	final private Pool<ByteWriteFieldAccess> bytePool = new Pool<ByteWriteFieldAccess>(new ByteResourceFactory());

	private static class CharResourceFactory implements ResourceFactory<CharWriteFieldAccess> {
		public CharWriteFieldAccess newInstance() {
			return new CharWriteFieldAccess();
		}
	}

	final private Pool<CharWriteFieldAccess> charPool = new Pool<CharWriteFieldAccess>(new CharResourceFactory());

	private static class ShortResourceFactory implements ResourceFactory<ShortWriteFieldAccess> {
		public ShortWriteFieldAccess newInstance() {
			return new ShortWriteFieldAccess();
		}
	}

	final private Pool<ShortWriteFieldAccess> shortPool = new Pool<ShortWriteFieldAccess>(new ShortResourceFactory());

	private static class IntResourceFactory implements ResourceFactory<IntWriteFieldAccess> {
		public IntWriteFieldAccess newInstance() {
			return new IntWriteFieldAccess();
		}
	}

	final private Pool<IntWriteFieldAccess> intPool = new Pool<IntWriteFieldAccess>(new IntResourceFactory());

	private static class LongResourceFactory implements ResourceFactory<LongWriteFieldAccess> {
		public LongWriteFieldAccess newInstance() {
			return new LongWriteFieldAccess();
		}
	}

	final private Pool<LongWriteFieldAccess> longPool = new Pool<LongWriteFieldAccess>(new LongResourceFactory());

	private static class FloatResourceFactory implements ResourceFactory<FloatWriteFieldAccess> {
		public FloatWriteFieldAccess newInstance() {
			return new FloatWriteFieldAccess();
		}
	}

	final private Pool<FloatWriteFieldAccess> floatPool = new Pool<FloatWriteFieldAccess>(new FloatResourceFactory());

	private static class DoubleResourceFactory implements ResourceFactory<DoubleWriteFieldAccess> {
		public DoubleWriteFieldAccess newInstance() {
			return new DoubleWriteFieldAccess();
		}
	}

	final private Pool<DoubleWriteFieldAccess> doublePool = new Pool<DoubleWriteFieldAccess>(
			new DoubleResourceFactory());

	@Override
	public void onIrrevocableAccess() {
	}
}
