package org.deuce.transaction.jvstmlfadapter;

import org.deuce.reflection.UnsafeHolder;
import org.deuce.transform.ExcludeInternal;

import sun.misc.Unsafe;

/**
 * @author Pascal Felber
 */
@ExcludeInternal
public class Field {

	static public Object getValue(Object reference, long field, Type type) {
		Unsafe unsafe = UnsafeHolder.getUnsafe();
		if (type == Type.BYTE) {
			return unsafe.getByte(reference, field);
		}
		else if (type == Type.BOOLEAN) { 
			return unsafe.getBoolean(reference, field);
		}
		else if (type == Type.CHAR) {
			return unsafe.getChar(reference, field);
		}
		else if (type == Type.SHORT) {
			return unsafe.getShort(reference, field);
		}
		else if (type == Type.INT) {
			return unsafe.getInt(reference, field);
		}
		else if (type == Type.LONG) {
			return unsafe.getLong(reference, field);
		}
		else if (type == Type.FLOAT) {
			return unsafe.getFloat(reference, field);
		}
		else if (type == Type.DOUBLE) {
			return unsafe.getDouble(reference, field);
		}
		else if (type == Type.OBJECT) {
			return unsafe.getObject(reference, field);
		}
		return null;
	}

	static public void putValue(Object reference, long field, Object value, Type type) {
		Unsafe unsafe = UnsafeHolder.getUnsafe();
	
		if (type == Type.BYTE) {
			unsafe.putByte(reference, field, (Byte) value);
		}
		else if (type == Type.BOOLEAN) {
			unsafe.putBoolean(reference, field, (Boolean) value);
		}
		else if (type == Type.CHAR) {
			unsafe.putChar(reference, field, (Character) value);
		}
		else if (type == Type.SHORT) {
			unsafe.putShort(reference, field, (Short) value);
		}
		else if (type == Type.INT) {
			unsafe.putInt(reference, field, (Integer) value);
		}
		else if (type == Type.LONG) {
			unsafe.putLong(reference, field, (Long) value);
		}
		else if (type == Type.FLOAT) {
			unsafe.putFloat(reference, field, (Float) value);
		}
		else if (type == Type.DOUBLE) {
			unsafe.putDouble(reference, field, (Double) value);
		}
		else if (type == Type.OBJECT) {
			unsafe.putObject(reference, field, value);
		}
	}
}