package org.deuce.transaction.jvstmlfadapter;

import jvstm.Transaction;
import jvstm.VBox;
import jvstm.WriteOnReadException;

import org.deuce.transaction.ContextDelegator;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxArrObjectField;

@ExcludeInternal
public class VBoxArrO extends TxArrObjectField implements VBoxAdapter {

	protected VBox<Object> vbox;
	
	public VBoxArrO(Object[] arr, int idx) {
		super(arr, idx);
		try {
			vbox = new VBox<Object>((Object)Field.getValue(ref, address, Type.OBJECT));
		}
		catch (WriteOnReadException e) {
			((Context)ContextDelegator.getInstance()).readOnWriteException();
		}
	}
	
	public VBoxArrO(Object[] arr, int idx, Object dummy) {
		super(arr, idx, dummy);
		try {
			vbox = new VBox<Object>((Object)Field.getValue(ref, address, Type.OBJECT));
		}
		catch (WriteOnReadException e) {
			((Context)ContextDelegator.getInstance()).readOnWriteException();
		}
	}
	

	@Override
	public VBox<Object> getVBox() {
		return vbox;
	}
	
	@Override
	public void write(Object value) {
//		vbox.body.value = value;
		Transaction.current().setBoxValue(vbox, value);
	}
	@Override
	public Object readObject() {
//		return vbox.body.value;
		return Transaction.current().getBoxValue(vbox);
	}
}
