package org.deuce.transaction.mvstmsi2.field;

import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public interface VBoxS extends VBox {

	void commit(short value, int txNumber);

}
