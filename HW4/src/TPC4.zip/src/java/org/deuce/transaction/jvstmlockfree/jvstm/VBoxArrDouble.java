/*
 * JVSTM: a Java library for Software Transactional Memory
 * Copyright (C) 2005 INESC-ID Software Engineering Group
 * http://www.esw.inesc-id.pt
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *
 * Author's contact:
 * INESC-ID Software Engineering Group
 * Rua Alves Redol 9
 * 1000 - 029 Lisboa
 * Portugal
 */
package org.deuce.transaction.jvstmlockfree.jvstm;

import static org.deuce.transaction.jvstmlockfree.jvstm.UtilUnsafe.UNSAFE;

import org.deuce.transform.inplacemetadata.type.TxArrDoubleField;

public class VBoxArrDouble extends TxArrDoubleField implements VBox<Double> {

	/**
     * We moved here all VBox constants that are initialized with Unsafe operations,
     * due to the JVSTM integration in Deuce.
     * To support the JVSTM all the transactional classes are instrumented by the Deuce
     * to inherit from the VBox class. Yet, if a transactional class is part of the JRE
     * it can be loaded during the bootstrap, but the JVM bootstrap does not allow the use of
     * Unsafe operations.
     * Once the original VBox implementation uses the Unsafe class in its static constructor
     * then any inherited class from VBox will perform also an unsafe operation when it is
     * loaded, which is forbidden by the JVM bootstrap. For this reason we moved all these
     * constants into a separate class.
     */
    static class Offsets {

        // --- Setup to use Unsafe
        static final long bodyOffset = UtilUnsafe.objectFieldOffset(VBoxArrDouble.class, "body");
        static final long inplaceOffset = UtilUnsafe.objectFieldOffset(VBoxArrDouble.class, "inplace");

    }

    

    public VBoxBody<Double> body;
    protected InplaceWrite<Double> inplace;


    public VBoxArrDouble(double[] ref, int address) {
    	super(ref, address);
        inplace = new InplaceWrite<Double>();
        this.body = VBoxStatic.makeNewBody(super.readDouble(), 0, null);
    }


    public OwnershipRecord getOrec(){
        return inplace.orec;
    }

    public Double get() {
        Transaction tx = Transaction.current();
        if (tx == null) {
            // Access the box body without creating a full transaction, while
            // still preserving ordering guarantees by 'piggybacking' on the
            // version from the latest commited transaction.
            // If the box body is GC'd before we can reach it, the process
            // re-starts with a newer transaction.
            while (true) {
                int transactionNumber = Transaction.mostRecentCommittedRecord.transactionNumber;
                VBoxBody<Double> boxBody = this.body;
                do {
                    if (boxBody.version <= transactionNumber) {
                        return boxBody.value;
                    }
                    boxBody = boxBody.next;
                } while (boxBody != null);
            }
        } else {
            return tx.getBoxValue(this, super.readDouble());
        }
    }

    public void put(Double newE) {
        Transaction tx = Transaction.current();
        if (tx == null) {
            tx = Transaction.beginInevitable();
            tx.setBoxValue(this, newE);
            tx.commit();
        } else {
            tx.setBoxValue(this, newE);
        }
    }

    public VBoxBody<?> commit(Double newValue, int txNumber) {
        VBoxBody<Double> currentHead = this.body;

        VBoxBody<Double> existingBody = null;
        if (currentHead != null) {
            existingBody = currentHead.getBody(txNumber);

            // Commented by FMC@17-09-2012 => it causes a crash in JVM for
            // transactional classes that inherit fom the VBox and loaded
            // during the bootstrap.
            // assert(existingBody == null || existingBody.version <= txNumber);
        }

        double tmp = super.readDouble();
        if (existingBody == currentHead && existingBody.version < txNumber) {
        	
        	VBoxBody<Double> newBody = VBoxStatic.makeNewBody(newValue, Integer.MAX_VALUE, currentHead);
        	
        	if (this.body == existingBody) {
        		currentHead.value = tmp;
        	}
        	existingBody = CASbody(currentHead, newBody, txNumber);
        	if (existingBody.version == Integer.MAX_VALUE) {
        		synchronized(this) {
        			if (tmp == super.readDouble()) {
        				write(newValue);
        			}
        		}
        	}
        	existingBody.version = txNumber;
        }
        else {
			if (existingBody.version < txNumber) {
				existingBody = currentHead;
				if (existingBody.version == Integer.MAX_VALUE) {
					synchronized(this) {
	        			if (tmp == super.readDouble()) {
	        				write(newValue);
	        			}
	        		}
				}
				existingBody.version = txNumber;
			}
        }
        
        return existingBody;
    }
    
    private VBoxBody<Double> CASbody(VBoxBody<Double> expected, VBoxBody<Double> newValue, int txNumber) {
    	if (UNSAFE.compareAndSwapObject(this, Offsets.bodyOffset, expected, newValue)) {
            return newValue;
        } else { // if the CAS failed the new value must already be there!
        	VBoxBody<Double> head = this.body;
            VBoxBody<Double> tmpBody = head.getBody(txNumber);
            if (tmpBody.version == txNumber) {
            	head = tmpBody;          
            }
            return head;
        }
	}

    /* Atomically replace the body with the new one iff the current body is the expected.
     *
     * Return the body that was actually kept.
     */
    @Override
    public VBoxBody<Double> CASbody(VBoxBody<Double> expected, VBoxBody<Double> newValue) {
        if (UNSAFE.compareAndSwapObject(this, Offsets.bodyOffset, expected, newValue)) {
            return newValue;
        } else { // if the CAS failed the new value must already be there!
            return this.body.getBody(newValue.version);
        }
    }
    
    @Override
    public boolean CASbody2(VBoxBody<Double> expected, VBoxBody<Double> newValue) {
        return UNSAFE.compareAndSwapObject(this, Offsets.bodyOffset, expected, newValue);
    }

    @Override
    public boolean CASinplace(InplaceWrite<Double> prevBackup, InplaceWrite<Double> newBackup) {
        return UNSAFE.compareAndSwapObject(this, Offsets.inplaceOffset, prevBackup, newBackup);
    }

    

    /*===========================================================================*
     *~~~~~~~~~~~~~     METHODS of the AOM approach     ~~~~~~~~~~~~~~~~~~~~~~~~~*
     *===========================================================================*/

    private static final String ILLEGAL_AOM_USE = "this method is part of the AOM (Adaptive Object Metadata) approach and " +
        "should be overriden by VBox inherited classes.";

    @Override
    public Double replicate(){
        throw new UnsupportedOperationException("Illegal use of the replicate method - " + ILLEGAL_AOM_USE);
    }
    @Override
    public void toCompactLayout(Double from){
        throw new UnsupportedOperationException("Illegal use of the toCompactLayout method - " + ILLEGAL_AOM_USE);
    }

    @Override
    public InplaceWrite<Double> inplace() {
    	return inplace;
    }
    
    @Override
    public InplaceWrite<Double> inplace(InplaceWrite<Double> write) {
    	return inplace = write;
    }
    
    @Override
    public VBoxBody<Double> body() {
    	return body;
    }
    
    @Override
    public VBoxBody<Double> body(VBoxBody<Double> body) {
    	return this.body = body;
    }
}
