package org.deuce.transaction.jvstmlfadapter;

import jvstm.Transaction;
import jvstm.VBox;
import jvstm.WriteOnReadException;

import org.deuce.transaction.ContextDelegator;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxArrDoubleField;

@ExcludeInternal
public class VBoxArrD extends TxArrDoubleField implements VBoxAdapter {

	protected VBox<Object> vbox;
	
	public VBoxArrD(double[] arr, int idx) {
		super(arr, idx);
		try {
			vbox = new VBox<Object>((Double)Field.getValue(ref, address, Type.DOUBLE));
		}
		catch (WriteOnReadException e) {
			((Context)ContextDelegator.getInstance()).readOnWriteException();
		}
	}

	@Override
	public VBox<Object> getVBox() {
		return vbox;
	}
	
	@Override
	public void write(double value) {
//		vbox.body.value = value;
		Transaction.current().setBoxValue(vbox, value);
	}
	@Override
	public double readDouble() {
//		return (Double) vbox.body.value;
		return (Double) Transaction.current().getBoxValue(vbox);
	}
}
