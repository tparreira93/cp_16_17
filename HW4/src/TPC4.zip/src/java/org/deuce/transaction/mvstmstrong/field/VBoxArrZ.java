package org.deuce.transaction.mvstmstrong.field;

import org.deuce.reflection.AddressUtil;
import org.deuce.reflection.UnsafeHolder;
import org.deuce.transaction.mvstmstrong.LockTable;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxArrBoolField;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public class VBoxArrZ extends TxArrBoolField implements VBoxZ {
	public volatile VersionZ version;

	public VBoxArrZ(boolean[] arr, int idx) {
	        super(arr, idx);
		version = new VersionZ(0, super.readBoolean(), null);
	}

	public boolean validate(Version version, int owner) {
		Version tmp = this.version;
		int l = lock;
		if ((l & LockTable.LOCK) != 0) {
			if ((l & LockTable.UNLOCK) != owner) {
				throw LockTable.LOCKED_VERSION_EXCEPTION;
			}
		}
		return tmp == version;
	}

	@Override
	public void commit(boolean newValue, int txNumber) {
		this.version = new VersionZ(txNumber, newValue, version);
	}

	@Override
	public Version get(int version) {
		Version tmp = this.version;
		if ((lock & LockTable.LOCK) != 0 || tmp.version > version) {
			throw LockTable.LOCKED_VERSION_EXCEPTION;
		}
		return tmp;
	}
	
	@Override
	public Version getRO(int version) {
		return this.version.get(version);
	}

	private static long __LOCK_FIELD__;
	static {
		try {
			__LOCK_FIELD__ = AddressUtil.getAddress(VBoxArrZ.class.getDeclaredField("lock"));
		} catch (SecurityException e) {
		} catch (NoSuchFieldException e) {
		}
	}
	public volatile int lock = 0;
	
	@Override
	public boolean lock(int owner) {
		int l = lock;
		if ((l & LockTable.LOCK) != 0) {
			throw LockTable.LOCKED_VERSION_EXCEPTION;
		}
		if (!UnsafeHolder.getUnsafe().compareAndSwapInt(this, __LOCK_FIELD__, l, l | owner | LockTable.LOCK)) {
			throw LockTable.LOCKED_VERSION_EXCEPTION;
		}
		return true;
	}

	@Override
	public void unLock() {
		lock = 0;
	}

	@Override
	public void write(boolean value) {
		version.value = value;
	}
	@Override
	public boolean readBoolean() {
		return version.value;
	}
}
