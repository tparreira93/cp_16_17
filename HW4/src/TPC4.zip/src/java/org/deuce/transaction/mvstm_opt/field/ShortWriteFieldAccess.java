package org.deuce.transaction.mvstm_opt.field;

import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public class ShortWriteFieldAccess extends WriteFieldAccess {

	public short value;

	public void set(short value, VBox field) {
		super.init(field);
		this.value = value;
	}

	@Override
	public void prepare() {
		((VBoxS)field).prepare(value);
	}

	public short getValue() {
		return value;
	}

}
