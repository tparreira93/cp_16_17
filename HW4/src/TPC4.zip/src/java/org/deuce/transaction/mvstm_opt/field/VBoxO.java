package org.deuce.transaction.mvstm_opt.field;

import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public interface VBoxO extends VBox {

	void prepare(Object value);

}
