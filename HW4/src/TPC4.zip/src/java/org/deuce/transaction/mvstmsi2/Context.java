package org.deuce.transaction.mvstmsi2;

import java.util.concurrent.atomic.AtomicInteger;

import org.deuce.InPlaceMetadata;
import org.deuce.transaction.TransactionException;
import org.deuce.transaction.mvstmsi2.field.BooleanWriteFieldAccess;
import org.deuce.transaction.mvstmsi2.field.ByteWriteFieldAccess;
import org.deuce.transaction.mvstmsi2.field.CharWriteFieldAccess;
import org.deuce.transaction.mvstmsi2.field.DoubleWriteFieldAccess;
import org.deuce.transaction.mvstmsi2.field.FloatWriteFieldAccess;
import org.deuce.transaction.mvstmsi2.field.IntWriteFieldAccess;
import org.deuce.transaction.mvstmsi2.field.LongWriteFieldAccess;
import org.deuce.transaction.mvstmsi2.field.ObjectWriteFieldAccess;
import org.deuce.transaction.mvstmsi2.field.ReadFieldAccess;
import org.deuce.transaction.mvstmsi2.field.ShortWriteFieldAccess;
import org.deuce.transaction.mvstmsi2.field.VBox;
import org.deuce.transaction.mvstmsi2.field.Version;
import org.deuce.transaction.mvstmsi2.field.VersionB;
import org.deuce.transaction.mvstmsi2.field.VersionC;
import org.deuce.transaction.mvstmsi2.field.VersionD;
import org.deuce.transaction.mvstmsi2.field.VersionF;
import org.deuce.transaction.mvstmsi2.field.VersionI;
import org.deuce.transaction.mvstmsi2.field.VersionL;
import org.deuce.transaction.mvstmsi2.field.VersionO;
import org.deuce.transaction.mvstmsi2.field.VersionS;
import org.deuce.transaction.mvstmsi2.field.VersionZ;
import org.deuce.transaction.mvstmsi2.field.WriteFieldAccess;
import org.deuce.transaction.mvstmsi2.pool.Pool;
import org.deuce.transaction.mvstmsi2.pool.ResourceFactory;
import org.deuce.transaction.util.BooleanArrayList;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxField;
import org.deuce.trove.TObjectProcedure;

/**
 * Versioned STM with bounded number of versions based in the JVSTM and TL2 algorithm.
 * This version uses lock per write-set entry during commit, as in TL2, opposed to
 * the global lock in the original JVSTM algorithm. 
 * 
 * This is the SnapshotIsolation Version
 * 
 * 
 * @author Ricardo Dias
 * @version Mar 19, 2013 16:39:19 PM
 *
 */
@ExcludeInternal
@InPlaceMetadata(
		fieldObjectClass="org.deuce.transaction.mvstmsi2.field.VBoxFieldO",
		fieldIntClass="org.deuce.transaction.mvstmsi2.field.VBoxFieldI",
		fieldShortClass="org.deuce.transaction.mvstmsi2.field.VBoxFieldS",
		fieldCharClass="org.deuce.transaction.mvstmsi2.field.VBoxFieldC",
		fieldByteClass="org.deuce.transaction.mvstmsi2.field.VBoxFieldB",
		fieldBooleanClass="org.deuce.transaction.mvstmsi2.field.VBoxFieldZ",
		fieldFloatClass="org.deuce.transaction.mvstmsi2.field.VBoxFieldF",
		fieldLongClass="org.deuce.transaction.mvstmsi2.field.VBoxFieldL",
		fieldDoubleClass="org.deuce.transaction.mvstmsi2.field.VBoxFieldD",
		
		arrayObjectClass="org.deuce.transaction.mvstmsi2.field.VBoxArrO",
		arrayIntClass="org.deuce.transaction.mvstmsi2.field.VBoxArrI",
		arrayShortClass="org.deuce.transaction.mvstmsi2.field.VBoxArrS",
		arrayCharClass="org.deuce.transaction.mvstmsi2.field.VBoxArrC",
		arrayByteClass="org.deuce.transaction.mvstmsi2.field.VBoxArrB",
		arrayBooleanClass="org.deuce.transaction.mvstmsi2.field.VBoxArrZ",
		arrayFloatClass="org.deuce.transaction.mvstmsi2.field.VBoxArrF",
		arrayLongClass="org.deuce.transaction.mvstmsi2.field.VBoxArrL",
		arrayDoubleClass="org.deuce.transaction.mvstmsi2.field.VBoxArrD"
			)
public final class Context extends org.deuce.transaction.ContextMetadata {

	private static final TransactionException READ_ONLY_FAILURE_EXCEPTION =
		new TransactionException("Fail on write (read-only hint was set).");
	
	public static final TransactionException VERSION_UNAVAILABLE_EXCEPTION =
		new TransactionException("Fail on retrieveing an older and unexistent version.");
	
	public static int MAX_VERSIONS = Integer.getInteger("org.deuce.transaction.mvstmsi2.versions", 16);
	
	final private static AtomicInteger threadID = new AtomicInteger(0);
	
	private final int id;
	
	
	private static final AtomicInteger clock = new AtomicInteger(0);
	
	private int localClock;
	
	private WriteSet writeSet = new WriteSet();
	
	// Keep per-thread read-only hints (uses more memory but faster)
	private final BooleanArrayList readWriteMarkers = new BooleanArrayList();
	private boolean readWriteHint = true;
	private int atomicBlockId;
	
	private final LockProcedure lockProcedure = new LockProcedure();
	
	
	public Context() {
		this.id = threadID.incrementAndGet();
		lockProcedure.owner = id;
	}
	
    
	public void initImpl(int blockId, String metainf) {
        atomicBlockId = blockId;
		readWriteHint = readWriteMarkers.get(atomicBlockId);
		
		this.writeSet.clear();
		this.localClock = clock.get();	
		
		this.objectPool.clear();
		this.booleanPool.clear();
		this.bytePool.clear();
		this.charPool.clear();
		this.shortPool.clear();
		this.intPool.clear();
		this.longPool.clear();
		this.floatPool.clear();
		this.doublePool.clear();
		
		lockProcedure.clear();
			
	}
	
	TObjectProcedure<WriteFieldAccess> putProcedure = 
		new TObjectProcedure<WriteFieldAccess>() {
		
		public boolean execute(WriteFieldAccess wfa) {
			wfa.put(localClock);	
			return true;
		}
	};
	
	private TObjectProcedure<WriteFieldAccess> validateProcedure = 
			new TObjectProcedure<WriteFieldAccess>() {
				
			public boolean execute(WriteFieldAccess wfa) {
				if (wfa.field.getTop() != wfa.version) {
	    			return false;
	    		}
				return true;
			}
		};
	

	public boolean commit() {
		
		if (readWriteHint) { 
			if (!writeSet.isEmpty()) {
				try {
					writeSet.forEach(lockProcedure);
					if (writeSet.forEach(validateProcedure)) {
						localClock = clock.get()+1;
						writeSet.forEach(putProcedure);
						clock.incrementAndGet();
					}
					else {
						return false;
					}
				}
				catch (TransactionException e) {
					return false;
				}
				finally {
					writeSet.forEach(lockProcedure.unlockProcedure);
				}
			}
		}
		return true;
	}
	
	
	public void rollback() {
	}

	
	
	protected Version lastReadVersion;
	
	public void beforeReadAccess(TxField field) {
		lastReadVersion = ((VBox)field).get(localClock);
	}
	
	private ReadFieldAccess dummy = new ReadFieldAccess();
	
	private WriteFieldAccess readLocal(VBox vbox) {
		dummy.init(vbox);		
        return writeSet.contains(dummy);
	}
	
	
	public Object onReadAccess(Object value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			WriteFieldAccess res = readLocal(box);
			if (res != null) {
				return ((ObjectWriteFieldAccess)res).value;
			}
		}
		
		return lastReadVersion == box.getTop() ? value : ((VersionO)lastReadVersion).value;
	}

	public boolean onReadAccess(boolean value, TxField field) {
		VBox box = (VBox)field;

		if (readWriteHint) {
			WriteFieldAccess res = readLocal(box);
			if (res != null) {
				return ((BooleanWriteFieldAccess)res).value;
			}
		}
		
		return lastReadVersion == box.getTop() ? value : ((VersionZ)lastReadVersion).value;
	}

	public byte onReadAccess(byte value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			WriteFieldAccess res = readLocal(box);
			if (res != null) {
				return ((ByteWriteFieldAccess)res).value;
			}
		}
		
		return lastReadVersion == box.getTop() ? value : ((VersionB)lastReadVersion).value;
	}

	public char onReadAccess(char value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			WriteFieldAccess res = readLocal(box);
			if (res != null) {
				return ((CharWriteFieldAccess)res).value;
			}
		}
		
		return lastReadVersion == box.getTop() ? value : ((VersionC)lastReadVersion).value;
	}

	public short onReadAccess(short value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			WriteFieldAccess res = readLocal(box);
			if (res != null) {
				return ((ShortWriteFieldAccess)res).value;
			}
		}
		
		return lastReadVersion == box.getTop() ? value : ((VersionS)lastReadVersion).value;
	}

	public int onReadAccess(int value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			WriteFieldAccess res = readLocal(box);
			if (res != null) {
				return ((IntWriteFieldAccess)res).value;
			}
		}
		
		return lastReadVersion == box.getTop() ? value : ((VersionI)lastReadVersion).value;
	}

	public long onReadAccess(long value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			WriteFieldAccess res = readLocal(box);
			if (res != null) {
				return ((LongWriteFieldAccess)res).value;
			}
		}
		
		return lastReadVersion == box.getTop() ? value : ((VersionL)lastReadVersion).value;
	}

	public float onReadAccess(float value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			WriteFieldAccess res = readLocal(box);
			if (res != null) {
				return ((FloatWriteFieldAccess)res).value;
			}
		}
		
		return lastReadVersion == box.getTop() ? value : ((VersionF)lastReadVersion).value;
	}

	public double onReadAccess(double value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			WriteFieldAccess res = readLocal(box);
			if (res != null) {
				return ((DoubleWriteFieldAccess)res).value;
			}
		}

		return lastReadVersion == box.getTop() ? value : ((VersionD)lastReadVersion).value;
	}

	public void onWriteAccess(Object value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		Version v = ((VBox)field).get(this.localClock);
		if (v != ((VBox)field).getTop()) {
			throw new TransactionException("Late write");
		}
		ObjectWriteFieldAccess write = objectPool.getNext();
		write.init((VBox)field, v);
		write.value = value;
		writeSet.put(write);
	}

	public void onWriteAccess(boolean value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		Version v = ((VBox)field).get(this.localClock);
		if (v != ((VBox)field).getTop()) {
			throw new TransactionException("Late write");
		}
		BooleanWriteFieldAccess write = booleanPool.getNext();
		write.init((VBox)field, v);
		write.value = value;
		writeSet.put(write);
	}

	public void onWriteAccess(byte value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		Version v = ((VBox)field).get(this.localClock);
		if (v != ((VBox)field).getTop()) {
			throw new TransactionException("Late write");
		}
		ByteWriteFieldAccess write = bytePool.getNext();
		write.init((VBox)field, v);
		write.value = value;
		writeSet.put(write);
	}

	public void onWriteAccess(char value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		Version v = ((VBox)field).get(this.localClock);
		if (v != ((VBox)field).getTop()) {
			throw new TransactionException("Late write");
		}
		CharWriteFieldAccess write = charPool.getNext();
		write.init((VBox)field, v);
		write.value = value;
		writeSet.put(write);
	}

	public void onWriteAccess(short value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		Version v = ((VBox)field).get(this.localClock);
		if (v != ((VBox)field).getTop()) {
			throw new TransactionException("Late write");
		}
		ShortWriteFieldAccess write = shortPool.getNext();
		write.init((VBox)field, v);
		write.value = value;
		writeSet.put(write);
	}

	public void onWriteAccess(int value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		Version v = ((VBox)field).get(this.localClock);
		if (v != ((VBox)field).getTop()) {
			throw new TransactionException("Late write");
		}
		IntWriteFieldAccess write = intPool.getNext();
		write.init((VBox)field, v);
		write.value = value;
		writeSet.put(write);
	}

	public void onWriteAccess(long value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		Version v = ((VBox)field).get(this.localClock);
		if (v != ((VBox)field).getTop()) {
			throw new TransactionException("Late write");
		}
		LongWriteFieldAccess write = longPool.getNext();
		write.init((VBox)field, v);
		write.value = value;
		writeSet.put(write);
	}

	public void onWriteAccess(float value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		Version v = ((VBox)field).get(this.localClock);
		if (v != ((VBox)field).getTop()) {
			throw new TransactionException("Late write");
		}
		FloatWriteFieldAccess write = floatPool.getNext();
		write.init((VBox)field, v);
		write.value = value;
		writeSet.put(write);
	}

	public void onWriteAccess(double value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		Version v = ((VBox)field).get(this.localClock);
		if (v != ((VBox)field).getTop()) {
			throw new TransactionException("Late write");
		}
		DoubleWriteFieldAccess write = doublePool.getNext();
		write.init((VBox)field, v);
		write.value = value;
		writeSet.put(write);
	}

	
	private static class ObjectResourceFactory implements ResourceFactory<ObjectWriteFieldAccess>{
		@Override
		public ObjectWriteFieldAccess newInstance() {
			return new ObjectWriteFieldAccess();
		}
	}
	final private Pool<ObjectWriteFieldAccess> objectPool = new Pool<ObjectWriteFieldAccess>(new ObjectResourceFactory());

	private static class BooleanResourceFactory implements ResourceFactory<BooleanWriteFieldAccess>{
		@Override
		public BooleanWriteFieldAccess newInstance() {
			return new BooleanWriteFieldAccess();
		}
	}
	final private Pool<BooleanWriteFieldAccess> booleanPool = new Pool<BooleanWriteFieldAccess>(new BooleanResourceFactory());

	private static class ByteResourceFactory implements ResourceFactory<ByteWriteFieldAccess>{
		@Override
		public ByteWriteFieldAccess newInstance() {
			return new ByteWriteFieldAccess();
		}
	}
	final private Pool<ByteWriteFieldAccess> bytePool = new Pool<ByteWriteFieldAccess>( new ByteResourceFactory());

	private static class CharResourceFactory implements ResourceFactory<CharWriteFieldAccess>{
		@Override
		public CharWriteFieldAccess newInstance() {
			return new CharWriteFieldAccess();
		}
	}
	final private Pool<CharWriteFieldAccess> charPool = new Pool<CharWriteFieldAccess>(new CharResourceFactory());

	private static class ShortResourceFactory implements ResourceFactory<ShortWriteFieldAccess>{
		@Override
		public ShortWriteFieldAccess newInstance() {
			return new ShortWriteFieldAccess();
		}
	}
	final private Pool<ShortWriteFieldAccess> shortPool = new Pool<ShortWriteFieldAccess>( new ShortResourceFactory());

	private static class IntResourceFactory implements ResourceFactory<IntWriteFieldAccess>{
		@Override
		public IntWriteFieldAccess newInstance() {
			return new IntWriteFieldAccess();
		}
	}
	final private Pool<IntWriteFieldAccess> intPool = new Pool<IntWriteFieldAccess>( new IntResourceFactory());

	private static class LongResourceFactory implements ResourceFactory<LongWriteFieldAccess>{
		@Override
		public LongWriteFieldAccess newInstance() {
			return new LongWriteFieldAccess();
		}
	}
	final private Pool<LongWriteFieldAccess> longPool = new Pool<LongWriteFieldAccess>( new LongResourceFactory());
	
	private static class FloatResourceFactory implements ResourceFactory<FloatWriteFieldAccess>{
		@Override
		public FloatWriteFieldAccess newInstance() {
			return new FloatWriteFieldAccess();
		}
	}
	final private Pool<FloatWriteFieldAccess> floatPool = new Pool<FloatWriteFieldAccess>( new FloatResourceFactory());
	
	private static class DoubleResourceFactory implements ResourceFactory<DoubleWriteFieldAccess>{
		@Override
		public DoubleWriteFieldAccess newInstance() {
			return new DoubleWriteFieldAccess();
		}
	}
	final private Pool<DoubleWriteFieldAccess> doublePool = new Pool<DoubleWriteFieldAccess>( new DoubleResourceFactory());


	@Override
	public void onIrrevocableAccess() {
		
	}
	

	

}
