package org.deuce.transaction.jvstminstrong.field;

public class BoolValue implements Value {
	public boolean value;
}
