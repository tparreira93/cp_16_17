package org.deuce.transaction.jvstminstrong;

import java.util.Map;

import org.deuce.InPlaceMetadata;
import org.deuce.transaction.TransactionException;
import org.deuce.transaction.jvstminstrong.field.BoolValue;
import org.deuce.transaction.jvstminstrong.field.ByteValue;
import org.deuce.transaction.jvstminstrong.field.CharValue;
import org.deuce.transaction.jvstminstrong.field.DoubleValue;
import org.deuce.transaction.jvstminstrong.field.FloatValue;
import org.deuce.transaction.jvstminstrong.field.IntValue;
import org.deuce.transaction.jvstminstrong.field.LongValue;
import org.deuce.transaction.jvstminstrong.field.ObjectValue;
import org.deuce.transaction.jvstminstrong.field.ShortValue;
import org.deuce.transaction.jvstminstrong.field.VBox;
import org.deuce.transaction.jvstminstrong.field.VBoxBBody;
import org.deuce.transaction.jvstminstrong.field.VBoxBody;
import org.deuce.transaction.jvstminstrong.field.VBoxCBody;
import org.deuce.transaction.jvstminstrong.field.VBoxDBody;
import org.deuce.transaction.jvstminstrong.field.VBoxFBody;
import org.deuce.transaction.jvstminstrong.field.VBoxIBody;
import org.deuce.transaction.jvstminstrong.field.VBoxLBody;
import org.deuce.transaction.jvstminstrong.field.VBoxOBody;
import org.deuce.transaction.jvstminstrong.field.VBoxSBody;
import org.deuce.transaction.jvstminstrong.field.VBoxZBody;
import org.deuce.transaction.jvstminstrong.field.Value;
import org.deuce.transaction.jvstminstrong.pool.Pool;
import org.deuce.transaction.jvstminstrong.pool.ResourceFactory;
import org.deuce.transaction.util.BooleanArrayList;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxField;
import org.deuce.trove.THashMap;
import org.deuce.trove.TObjectObjectProcedure;

/**
 * JVSTM Implementation
 * 
 * JVSTM is a multiversion STM for Java developed by Joao Cachopo 
 * from INESC-ID.
 * 
 * @author Ricardo Dias
 * @version Oct 05, 2010 22:48:19 PM
 *
 */
@ExcludeInternal
@InPlaceMetadata(
		fieldObjectClass="org.deuce.transaction.jvstminstrong.field.VBoxO",
		fieldIntClass="org.deuce.transaction.jvstminstrong.field.VBoxI",
		fieldShortClass="org.deuce.transaction.jvstminstrong.field.VBoxS",
		fieldCharClass="org.deuce.transaction.jvstminstrong.field.VBoxC",
		fieldByteClass="org.deuce.transaction.jvstminstrong.field.VBoxB",
		fieldBooleanClass="org.deuce.transaction.jvstminstrong.field.VBoxZ",
		fieldFloatClass="org.deuce.transaction.jvstminstrong.field.VBoxF",
		fieldLongClass="org.deuce.transaction.jvstminstrong.field.VBoxL",
		fieldDoubleClass="org.deuce.transaction.jvstminstrong.field.VBoxD",
		
		arrayObjectClass="org.deuce.transaction.jvstminstrong.field.VBoxArrO",
		arrayIntClass="org.deuce.transaction.jvstminstrong.field.VBoxArrI",
		arrayShortClass="org.deuce.transaction.jvstminstrong.field.VBoxArrS",
		arrayCharClass="org.deuce.transaction.jvstminstrong.field.VBoxArrC",
		arrayByteClass="org.deuce.transaction.jvstminstrong.field.VBoxArrB",
		arrayBooleanClass="org.deuce.transaction.jvstminstrong.field.VBoxArrZ",
		arrayFloatClass="org.deuce.transaction.jvstminstrong.field.VBoxArrF",
		arrayLongClass="org.deuce.transaction.jvstminstrong.field.VBoxArrL",
		arrayDoubleClass="org.deuce.transaction.jvstminstrong.field.VBoxArrD"
			)
public final class Context extends org.deuce.transaction.ContextMetadata {

	private static final TransactionException READ_ONLY_FAILURE_EXCEPTION =
		new TransactionException("Fail on write (read-only hint was set).");
	
	private static volatile ActiveTransactionsRecord mostRecentRecord = new ActiveTransactionsRecord(0, null);
	
	private int localClock;
	private ActiveTransactionsRecord activeTxRecord;
	
	private Cons<Pair<VBox,VBoxBody>> bodiesRead = Cons.empty();
	private Map<VBox,Value> boxesWritten = new THashMap<VBox, Value>();
	
	// Keep per-thread read-only hints (uses more memory but faster)
	private final BooleanArrayList readWriteMarkers = new BooleanArrayList();
	private boolean readWriteHint = true;
	private int atomicBlockId;
	
	private Cons<VBoxBody> newBodies = Cons.empty();
	
	
	private static int getMostRecentCommitedNumber() {
        return mostRecentRecord.transactionNumber;
    }
	
	// this method is called during the commit of a write transaction
    // the commits are already synchronized, so this method doesn't need to be
    private static void setMostRecentActiveRecord(ActiveTransactionsRecord record) {
        mostRecentRecord.setNext(record);
        mostRecentRecord = record;
    }
    
	public void initImpl(int blockId, String metainf) {
		activeTxRecord = mostRecentRecord.getRecordForNewTransaction();
		localClock = activeTxRecord.transactionNumber;
		
		bodiesRead = null;
		bodiesRead = Cons.empty();
		
		boxesWritten.clear();
        newBodies = Cons.empty();
        
        atomicBlockId = blockId;
		readWriteHint = readWriteMarkers.get(atomicBlockId);
		
		this.objectPool.clear();
		this.booleanPool.clear();
		this.bytePool.clear();
		this.charPool.clear();
		this.shortPool.clear();
		this.intPool.clear();
		this.longPool.clear();
		this.floatPool.clear();
		this.doublePool.clear();
			
	}
	

	public boolean commit() {
		if (readWriteHint) { 
			if (!boxesWritten.isEmpty()) {
				synchronized(Context.class) {
					if (validate()) {
						apply();
					}
					else {
						activeTxRecord.decrementRunning();
						return false;
					}
				}
			}
		}
		activeTxRecord.decrementRunning();
		return true;
	}
	
	
	public void rollback() {
		activeTxRecord.decrementRunning();
	}

	private final boolean validate() {
		for (Pair<VBox,VBoxBody> entry : bodiesRead) {
			if (!entry.first.validate(entry.second)) {
				return false;
			}
		}
		return true;
	}

	
	
	
	TObjectObjectProcedure<VBox, Value> putProcedure = 
		new TObjectObjectProcedure<VBox, Value>() {
		
		public boolean execute(VBox vbox, Value newValue) {
			VBoxBody newBody = vbox.commit(newValue, localClock);			
			
			newBodies = newBodies.cons(newBody);
			
			return true;
		}
	};
	
	private final void apply() {
		int newTxNumber = getMostRecentCommitedNumber() + 1;
		localClock = newTxNumber;

		
		((THashMap<VBox, Value>)boxesWritten).forEachEntry(putProcedure);
		
		
        
        ActiveTransactionsRecord newRecord = new ActiveTransactionsRecord(newTxNumber, newBodies);
        setMostRecentActiveRecord(newRecord);
        newRecord.incrementRunning();
        activeTxRecord.decrementRunning();
        activeTxRecord = newRecord;
	}
	
	
	
	
	
	public void beforeReadAccess(TxField field) {
		

	}
	
	
	private Value readLocal(VBox vbox) {
		Value value = null;
		
        value = boxesWritten.get(vbox);
        
        return value;
	}
	
	
	public Object onReadAccess(Object value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			Value res = readLocal(box);
			if (res != null) {
				return ((ObjectValue)res).value;
			}
		}
		
		VBoxBody body = box.getBody(localClock); 
		
		if (readWriteHint) {
			bodiesRead = bodiesRead.cons(new Pair<VBox,VBoxBody>(box, body));
		}
		
		return ((VBoxOBody)body).value;
	}

	public boolean onReadAccess(boolean value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			Value res = readLocal(box);
			if (res != null) {
				return ((BoolValue)res).value;
			}
		}
		
		VBoxBody body = box.getBody(localClock); 
		
		if (readWriteHint) {
			bodiesRead = bodiesRead.cons(new Pair<VBox,VBoxBody>(box, body));
		}
		
		return ((VBoxZBody)body).value;
	}

	public byte onReadAccess(byte value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			Value res = readLocal(box);
			if (res != null) {
				return ((ByteValue)res).value;
			}
		}
		
		VBoxBody body = box.getBody(localClock); 
		
		if (readWriteHint) {
			bodiesRead = bodiesRead.cons(new Pair<VBox,VBoxBody>(box, body));
		}
		
		return ((VBoxBBody)body).value;
	}

	public char onReadAccess(char value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			Value res = readLocal(box);
			if (res != null) {
				return ((CharValue)res).value;
			}
		}
		
		VBoxBody body = box.getBody(localClock); 
		
		if (readWriteHint) {
			bodiesRead = bodiesRead.cons(new Pair<VBox,VBoxBody>(box, body));
		}
		
		return ((VBoxCBody)body).value;
	}

	public short onReadAccess(short value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			Value res = readLocal(box);
			if (res != null) {
				return ((ShortValue)res).value;
			}
		}
		
		VBoxBody body = box.getBody(localClock); 
		
		if (readWriteHint) {
			bodiesRead = bodiesRead.cons(new Pair<VBox,VBoxBody>(box, body));
		}
		
		return ((VBoxSBody)body).value;
	}

	public int onReadAccess(int value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			Value res = readLocal(box);
			if (res != null) {
				return ((IntValue)res).value;
			}
		}
		
		VBoxBody body = box.getBody(localClock); 
		
		if (readWriteHint) {
			bodiesRead = bodiesRead.cons(new Pair<VBox,VBoxBody>(box, body));
		}
		
		
		return ((VBoxIBody)body).value;
	}

	public long onReadAccess(long value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			Value res = readLocal(box);
			if (res != null) {
				return ((LongValue)res).value;
			}
		}
		
		VBoxBody body = box.getBody(localClock); 
		
		if (readWriteHint) {
			bodiesRead = bodiesRead.cons(new Pair<VBox,VBoxBody>(box, body));
		}
		
		return ((VBoxLBody)body).value;
	}

	public float onReadAccess(float value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			Value res = readLocal(box);
			if (res != null) {
				return ((FloatValue)res).value;
			}
		}
		
		VBoxBody body = box.getBody(localClock); 
		
		if (readWriteHint) {
			bodiesRead = bodiesRead.cons(new Pair<VBox,VBoxBody>(box, body));
		}
		
		return ((VBoxFBody)body).value;
	}

	public double onReadAccess(double value, TxField field) {
		VBox box = (VBox)field;
		
		if (readWriteHint) {
			Value res = readLocal(box);
			if (res != null) {
				return ((DoubleValue)res).value;
			}
		}
		
		VBoxBody body = box.getBody(localClock); 
		
		if (readWriteHint) {
			bodiesRead = bodiesRead.cons(new Pair<VBox,VBoxBody>(box, body));
		}
		
		return ((VBoxDBody)body).value;
	}

	public void onWriteAccess(Object value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		ObjectValue v = objectPool.getNext();
		v.value = value;
		boxesWritten.put((VBox)field, v);
	}

	public void onWriteAccess(boolean value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		BoolValue v = booleanPool.getNext();
		v.value = value;
		boxesWritten.put((VBox)field, v);
	}

	public void onWriteAccess(byte value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		ByteValue v = bytePool.getNext();
		v.value = value;
		boxesWritten.put((VBox)field, v);
	}

	public void onWriteAccess(char value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		CharValue v = charPool.getNext();
		v.value = value;
		boxesWritten.put((VBox)field, v);
	}

	public void onWriteAccess(short value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		ShortValue v = shortPool.getNext();
		v.value = value;
		boxesWritten.put((VBox)field, v);
	}

	public void onWriteAccess(int value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		IntValue v = intPool.getNext();
		v.value = value;
		boxesWritten.put((VBox)field, v);
	}

	public void onWriteAccess(long value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		LongValue v = longPool.getNext();
		v.value = value;
		boxesWritten.put((VBox)field, v);
	}

	public void onWriteAccess(float value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		FloatValue v = floatPool.getNext();
		v.value = value;
		boxesWritten.put((VBox)field, v);
	}

	public void onWriteAccess(double value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		
		DoubleValue v = doublePool.getNext();
		v.value = value;
		boxesWritten.put((VBox)field, v);
	}

	
	private static class ObjectResourceFactory implements ResourceFactory<ObjectValue>{
		@Override
		public ObjectValue newInstance() {
			return new ObjectValue();
		}
	}
	final private Pool<ObjectValue> objectPool = new Pool<ObjectValue>(new ObjectResourceFactory());

	private static class BooleanResourceFactory implements ResourceFactory<BoolValue>{
		@Override
		public BoolValue newInstance() {
			return new BoolValue();
		}
	}
	final private Pool<BoolValue> booleanPool = new Pool<BoolValue>(new BooleanResourceFactory());

	private static class ByteResourceFactory implements ResourceFactory<ByteValue>{
		@Override
		public ByteValue newInstance() {
			return new ByteValue();
		}
	}
	final private Pool<ByteValue> bytePool = new Pool<ByteValue>( new ByteResourceFactory());

	private static class CharResourceFactory implements ResourceFactory<CharValue>{
		@Override
		public CharValue newInstance() {
			return new CharValue();
		}
	}
	final private Pool<CharValue> charPool = new Pool<CharValue>(new CharResourceFactory());

	private static class ShortResourceFactory implements ResourceFactory<ShortValue>{
		@Override
		public ShortValue newInstance() {
			return new ShortValue();
		}
	}
	final private Pool<ShortValue> shortPool = new Pool<ShortValue>( new ShortResourceFactory());

	private static class IntResourceFactory implements ResourceFactory<IntValue>{
		@Override
		public IntValue newInstance() {
			return new IntValue();
		}
	}
	final private Pool<IntValue> intPool = new Pool<IntValue>( new IntResourceFactory());

	private static class LongResourceFactory implements ResourceFactory<LongValue>{
		@Override
		public LongValue newInstance() {
			return new LongValue();
		}
	}
	final private Pool<LongValue> longPool = new Pool<LongValue>( new LongResourceFactory());
	
	private static class FloatResourceFactory implements ResourceFactory<FloatValue>{
		@Override
		public FloatValue newInstance() {
			return new FloatValue();
		}
	}
	final private Pool<FloatValue> floatPool = new Pool<FloatValue>( new FloatResourceFactory());
	
	private static class DoubleResourceFactory implements ResourceFactory<DoubleValue>{
		@Override
		public DoubleValue newInstance() {
			return new DoubleValue();
		}
	}
	final private Pool<DoubleValue> doublePool = new Pool<DoubleValue>( new DoubleResourceFactory());


	@Override
	public void onIrrevocableAccess() {
		
		
	}
	

	

}
