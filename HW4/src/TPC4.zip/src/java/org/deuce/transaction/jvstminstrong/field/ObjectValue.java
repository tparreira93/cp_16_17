package org.deuce.transaction.jvstminstrong.field;

public class ObjectValue implements Value {
	public Object value;
}
