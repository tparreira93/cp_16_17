package org.deuce.transaction.jvstmlfadapter;

import jvstm.Transaction;
import jvstm.VBox;
import jvstm.WriteOnReadException;

import org.deuce.transaction.ContextDelegator;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxField;

@ExcludeInternal
public class VBoxFieldS extends TxField implements VBoxAdapter {

	protected VBox<Object> vbox;
	
	public VBoxFieldS(Object ref, long address) {
		super(ref, address);
		try {
			vbox = new VBox<Object>((Short)Field.getValue(ref, address, Type.SHORT));
		}
		catch (WriteOnReadException e) {
			((Context)ContextDelegator.getInstance()).readOnWriteException();
		}
	}
	
	@Override
	public VBox<Object> getVBox() {
		return vbox;
	}

	@Override
	public void write(short value) {
//		vbox.body.value = value;
		Transaction.current().setBoxValue(vbox, value);
	}
	@Override
	public short readShort() {
//		return (Short) vbox.body.value;
		return (Short) Transaction.current().getBoxValue(vbox);
	}
}
