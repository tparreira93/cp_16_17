package org.deuce.transaction.jvstminstrong.field;

public class IntValue implements Value {
	public int value;
}
