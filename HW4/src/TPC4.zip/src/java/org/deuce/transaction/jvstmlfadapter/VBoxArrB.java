package org.deuce.transaction.jvstmlfadapter;

import jvstm.Transaction;
import jvstm.VBox;
import jvstm.WriteOnReadException;

import org.deuce.transaction.ContextDelegator;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxArrByteField;

@ExcludeInternal
public class VBoxArrB extends TxArrByteField implements VBoxAdapter {

	protected VBox<Object> vbox;
	
	public VBoxArrB(byte[] arr, int idx) {
		super(arr, idx);
		try {
			vbox = new VBox<Object>((Byte)Field.getValue(ref, address, Type.BYTE));
		}
		catch (WriteOnReadException e) {
			((Context)ContextDelegator.getInstance()).readOnWriteException();
		}
	}

	@Override
	public VBox<Object> getVBox() {
		return vbox;
	}
	
	@Override
	public void write(byte value) {
//		vbox.body.value = value;
		Transaction.current().setBoxValue(vbox, value);
	}
	@Override
	public byte readByte() {
//		return (Byte) vbox.body.value;
		return (Byte) Transaction.current().getBoxValue(vbox);
	}
}
