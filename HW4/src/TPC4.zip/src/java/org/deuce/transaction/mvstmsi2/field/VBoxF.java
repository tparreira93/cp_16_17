package org.deuce.transaction.mvstmsi2.field;

import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public interface VBoxF extends VBox {

	void commit(float value, int txNumber);

}
