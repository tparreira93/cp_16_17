package org.deuce.transaction.mvstmsi2.pool;

public interface ResourceFactory<T>{
	T newInstance();
}
