package org.deuce.transaction.jvstmlfadapter;

import jvstm.Transaction;
import jvstm.VBox;
import jvstm.WriteOnReadException;

import org.deuce.transaction.ContextDelegator;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxArrIntField;

@ExcludeInternal
public class VBoxArrI extends TxArrIntField implements VBoxAdapter {

	protected VBox<Object> vbox;
	
	public VBoxArrI(int[] arr, int idx) {
		super(arr, idx);
		try {
			vbox = new VBox<Object>((Integer)Field.getValue(ref, address, Type.INT));
		}
		catch (WriteOnReadException e) {
			((Context)ContextDelegator.getInstance()).readOnWriteException();
		}
	}

	@Override
	public VBox<Object> getVBox() {
		return vbox;
	}

	@Override
	public void write(int value) {
//		vbox.body.value = value;
		Transaction.current().setBoxValue(vbox, value);
	}
	@Override
	public int readInt() {
//		return (Integer) vbox.body.value;
		return (Integer) Transaction.current().getBoxValue(vbox);
	}
}
