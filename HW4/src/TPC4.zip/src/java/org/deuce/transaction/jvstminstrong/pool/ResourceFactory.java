package org.deuce.transaction.jvstminstrong.pool;

public interface ResourceFactory<T>{
	T newInstance();
}
