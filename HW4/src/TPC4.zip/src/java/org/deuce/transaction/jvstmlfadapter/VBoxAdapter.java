package org.deuce.transaction.jvstmlfadapter;

import jvstm.VBox;

import org.deuce.transform.ExcludeInternal;

@ExcludeInternal
public interface VBoxAdapter {
	VBox<Object> getVBox();
}
