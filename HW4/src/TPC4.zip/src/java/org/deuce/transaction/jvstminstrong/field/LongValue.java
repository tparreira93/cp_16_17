package org.deuce.transaction.jvstminstrong.field;

public class LongValue implements Value {
	public long value;
}
