package org.deuce.transaction.jvstmlfadapter;

import jvstm.Transaction;
import jvstm.VBox;
import jvstm.WriteOnReadException;

import org.deuce.transaction.ContextDelegator;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxArrBoolField;

@ExcludeInternal
public class VBoxArrZ extends TxArrBoolField implements VBoxAdapter {

	protected VBox<Object> vbox;
	
	public VBoxArrZ(boolean[] arr, int idx) {
		super(arr, idx);
		try {
			vbox = new VBox<Object>((Boolean)Field.getValue(ref, address, Type.BOOLEAN));
		}
		catch (WriteOnReadException e) {
			((Context)ContextDelegator.getInstance()).readOnWriteException();
		}
	}

	@Override
	public VBox<Object> getVBox() {
		return vbox;
	}

	@Override
	public void write(boolean value) {
//		vbox.body.value = value;
		Transaction.current().setBoxValue(vbox, value);
	}
	@Override
	public boolean readBoolean() {
//		return (Boolean) vbox.body.value;
		return (Boolean) Transaction.current().getBoxValue(vbox);
	}
}
