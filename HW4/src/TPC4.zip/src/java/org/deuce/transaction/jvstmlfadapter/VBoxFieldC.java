package org.deuce.transaction.jvstmlfadapter;

import jvstm.Transaction;
import jvstm.VBox;
import jvstm.WriteOnReadException;

import org.deuce.transaction.ContextDelegator;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxField;

@ExcludeInternal
public class VBoxFieldC extends TxField implements VBoxAdapter {

	protected VBox<Object> vbox;
	
	public VBoxFieldC(Object ref, long address) {
		super(ref, address);
		try {
			vbox = new VBox<Object>((Character)Field.getValue(ref, address, Type.CHAR));
		}
		catch (WriteOnReadException e) {
			((Context)ContextDelegator.getInstance()).readOnWriteException();
		}
	}
	
	@Override
	public VBox<Object> getVBox() {
		return vbox;
	}

	@Override
	public void write(char value) {
//		vbox.body.value = value;
		Transaction.current().setBoxValue(vbox, value);
	}
	@Override
	public char readChar() {
//		return (Character) vbox.body.value;
		return (Character) Transaction.current().getBoxValue(vbox);
	}
}
