
package org.deuce.transaction.jvstmlockfree;


import org.deuce.InPlaceMetadata;
import org.deuce.transaction.ContextMetadata;
import org.deuce.transaction.TransactionException;
import org.deuce.transaction.jvstmlockfree.jvstm.Transaction;
import org.deuce.transaction.jvstmlockfree.jvstm.TransactionSignaller;
import org.deuce.transaction.jvstmlockfree.jvstm.VBox;
import org.deuce.transaction.jvstmlockfree.jvstm.VBoxBody;
import org.deuce.transaction.util.BooleanArrayList;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxField;

/**
 * JVSTM Lock-Free implementation using in-place metadata extension.
 * This implementation is based on the adaptation of Deuce to support JVSTM 
 * by Fernando Carvalho.
 * 
 * @author Ricardo Dias
 *
 */
@ExcludeInternal
@InPlaceMetadata(
		fieldObjectClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxObject",
		fieldIntClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxInt",
		fieldShortClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxShort",
		fieldCharClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxChar",
		fieldByteClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxByte",
		fieldBooleanClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxBoolean",
		fieldFloatClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxFloat",
		fieldLongClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxLong",
		fieldDoubleClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxDouble",
		
		arrayObjectClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxArrObject",
		arrayIntClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxArrInt",
		arrayShortClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxArrShort",
		arrayCharClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxArrChar",
		arrayByteClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxArrByte",
		arrayBooleanClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxArrBoolean",
		arrayFloatClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxArrFloat",
		arrayLongClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxArrLong",
		arrayDoubleClass="org.deuce.transaction.jvstmlockfree.jvstm.VBoxArrDouble"
			)
public class Context extends ContextMetadata {

	private static final TransactionException READ_ONLY_FAILURE_EXCEPTION =
			new TransactionException("Fail on write (read-only hint was set).");
	
	// Keep per-thread read-only hints (uses more memory but faster)
	private final BooleanArrayList readWriteMarkers = new BooleanArrayList();
	private boolean readWriteHint = true;
	private int atomicBlockId;
	
	static {
		TransactionSignaller.setSignaller(new TransactionSignaller() {

			@Override
			public void signalEarlyAbort() {
				throw new TransactionException();
			}

			@Override
			public void signalCommitFail(Transaction tx) {
				throw new TransactionException();
			}

			@Override
			public void signalCommitFail() {
				throw new TransactionException();
			}
		});
	}
	
	protected Transaction currentTrx;
	
	public void readOnWriteException() throws TransactionException {
		readWriteMarkers.insert(atomicBlockId, true);
		throw READ_ONLY_FAILURE_EXCEPTION;
	}
	
	@Override
	public void initImpl(int blockId, String metainf) {
		this.atomicBlockId = blockId;
		readWriteHint = readWriteMarkers.get(atomicBlockId);
		currentTrx = Transaction.begin(!readWriteHint);
	}

	@Override
	public boolean commit() {
		try {
			currentTrx.commitTx(true); // Commit and finish also.
		} catch (TransactionException e) {
			rollback();  
			return false;
		} finally{
			/*
			 * In the case of a nested transaction, when it finishes we must update the 
			 * currentTrx with its parent that has been already up to date in the
			 * transaction's context.
			 */
			currentTrx = Transaction.current(); 
		}
		return true;
	}

	@Override
	public void rollback() {
		currentTrx.abortTx();
		/*
		 * In the case of a nested transaction, when it finishes we must update the 
		 * currentTrx with its parent that has been already up to date in the
		 * transaction's context.
		 */
		currentTrx = Transaction.current();
	}

	@Override
	public void onIrrevocableAccess() {

	}
	
	protected VBoxBody<?> lastReadVersion;

	@Override
	public void beforeReadAccess(TxField field) {
		//useless for the JVSTM but important for supporting weak atomicity instrumentation
//		lastReadVersion = ((VBox<?>)field).body().getBody(currentTrx.getNumber());
	}

	@Override
	public Object onReadAccess(Object value, TxField field) {
		return currentTrx.getBoxValue((VBox)field, value);
	}

	@Override
	public boolean onReadAccess(boolean value, TxField field) {
		return (Boolean)currentTrx.getBoxValue((VBox)field, value);
	}

	@Override
	public byte onReadAccess(byte value, TxField field) {
		return (Byte)currentTrx.getBoxValue((VBox)field, value);
	}

	@Override
	public char onReadAccess(char value, TxField field) {
		return (Character)currentTrx.getBoxValue((VBox)field, value);
	}

	@Override
	public short onReadAccess(short value, TxField field) {
		return (Short)currentTrx.getBoxValue((VBox)field, value);
	}

	@Override
	public int onReadAccess(int value, TxField field) {
		return (Integer)currentTrx.getBoxValue((VBox)field, value);
	}

	@Override
	public long onReadAccess(long value, TxField field) {
		return (Long)currentTrx.getBoxValue((VBox)field, value);
	}

	@Override
	public float onReadAccess(float value, TxField field) {
		return (Float)currentTrx.getBoxValue((VBox)field, value);
	}

	@Override
	public double onReadAccess(double value, TxField field) {
		return (Double)currentTrx.getBoxValue((VBox)field, value);
	}

	@Override
	public void onWriteAccess(Object value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		currentTrx.setBoxValue((VBox)field, value);
	}

	@Override
	public void onWriteAccess(boolean value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		currentTrx.setBoxValue((VBox)field, value);
	}

	@Override
	public void onWriteAccess(byte value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		currentTrx.setBoxValue((VBox)field, value);
	}

	@Override
	public void onWriteAccess(char value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		currentTrx.setBoxValue((VBox)field, value);
	}

	@Override
	public void onWriteAccess(short value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		currentTrx.setBoxValue((VBox)field, value);
	}

	@Override
	public void onWriteAccess(int value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		currentTrx.setBoxValue((VBox)field, value);
	}

	@Override
	public void onWriteAccess(long value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		currentTrx.setBoxValue((VBox)field, value);
	}

	@Override
	public void onWriteAccess(float value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		currentTrx.setBoxValue((VBox)field, value);
	}

	@Override
	public void onWriteAccess(double value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
		currentTrx.setBoxValue((VBox)field, value);
	}

}
