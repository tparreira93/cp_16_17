package org.deuce.transaction.smv;

import java.util.concurrent.atomic.AtomicInteger;

import org.deuce.InPlaceMetadata;
import org.deuce.transaction.ContextMetadata;
import org.deuce.transaction.TransactionException;
import org.deuce.transaction.smv.smvimpl.ForcefulAbortException;
import org.deuce.transaction.smv.smvimpl.SMVAbstractTransaction;
import org.deuce.transaction.smv.smvimpl.SMVFieldInterface;
import org.deuce.transaction.smv.smvimpl.SMVROTransaction;
import org.deuce.transaction.smv.smvimpl.SMVUpdateTransaction;
import org.deuce.transaction.smv.smvimpl.Type;
import org.deuce.transaction.util.BooleanArrayList;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxField;

/**
 * 
 * Implementation of the SMV algorithm presented in DISC'11
 * This implementation is based on the SMV source code from 
 * http://tx.technion.ac.il/~dima39/sourcecode/SMVLib-29-06-11.zip
 * 
 * @author Ricardo Dias
 *
 */
@ExcludeInternal
@InPlaceMetadata(
		fieldObjectClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLight",
		fieldIntClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLight",
		fieldShortClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLight",
		fieldCharClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLight",
		fieldByteClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLight",
		fieldBooleanClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLight",
		fieldFloatClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLight",
		fieldLongClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLight",
		fieldDoubleClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLight",
		
		arrayObjectClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLightArrObject",
		arrayIntClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLightArrInt",
		arrayShortClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLightArrShort",
		arrayCharClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLightArrChar",
		arrayByteClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLightArrByte",
		arrayBooleanClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLightArrBoolean",
		arrayFloatClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLightArrFloat",
		arrayLongClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLightArrLong",
		arrayDoubleClass="org.deuce.transaction.smv.smvimpl.SMVAdapterLightArrDouble"
			)
public class Context extends ContextMetadata {
	
	private static final TransactionException READ_ONLY_FAILURE_EXCEPTION =
			new TransactionException("Fail on write (read-only hint was set).");

	// Keep per-thread read-only hints (uses more memory but faster)
	private final BooleanArrayList readWriteMarkers = new BooleanArrayList();
	private boolean readWriteHint = true;
	private int atomicBlockId;
	
	// SMV Transactional Descriptor
	private SMVAbstractTransaction txn = null;
	
	public static AtomicInteger idgen = new AtomicInteger(0);
	
	@Override
	public void initImpl(int atomicBlockId, String metainf) {
		this.atomicBlockId = atomicBlockId;
		readWriteHint = readWriteMarkers.get(atomicBlockId);

		txn = readWriteHint ? new SMVUpdateTransaction(0) : new SMVROTransaction(0);
		txn.start();
	}

	@Override
	public boolean commit() {
		try {
			return txn.commit();
		}
		catch(ForcefulAbortException e) {
			txn.abort();
			return false;
		}
	}

	@Override
	public void rollback() {
		txn.abort();
	}

	@Override
	public void onIrrevocableAccess() {

	}

	@Override
	public void beforeReadAccess(TxField field) {

	}

	@Override
	public Object onReadAccess(Object value, TxField field) {
		return txn.readAccess((SMVFieldInterface)field, value, Type.OBJECT);
	}

	@Override
	public boolean onReadAccess(boolean value, TxField field) {
		return (Boolean)(txn.readAccess((SMVFieldInterface)field, value, Type.BOOLEAN));
	}

	@Override
	public byte onReadAccess(byte value, TxField field) {
		return (Byte)(txn.readAccess((SMVFieldInterface)field, value, Type.BYTE));
	}

	@Override
	public char onReadAccess(char value, TxField field) {
		return (Character)(txn.readAccess((SMVFieldInterface)field, value, Type.CHAR));
	}

	@Override
	public short onReadAccess(short value, TxField field) {
		return (Short)(txn.readAccess((SMVFieldInterface)field, value, Type.SHORT));
	}

	@Override
	public int onReadAccess(int value, TxField field) {
		return (Integer)(txn.readAccess((SMVFieldInterface)field, value, Type.INT));
	}

	@Override
	public long onReadAccess(long value, TxField field) {
		return (Long)(txn.readAccess((SMVFieldInterface)field, value, Type.LONG));
	}

	@Override
	public float onReadAccess(float value, TxField field) {
		return (Float)(txn.readAccess((SMVFieldInterface)field, value, Type.FLOAT));
	}

	@Override
	public double onReadAccess(double value, TxField field) {
		return (Double)(txn.readAccess((SMVFieldInterface)field, value, Type.DOUBLE));
	}

	@Override
	public void onWriteAccess(Object value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
			txn.writeAccess((SMVFieldInterface)field, value, Type.OBJECT);
			
	}

	@Override
	public void onWriteAccess(boolean value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
			txn.writeAccess((SMVFieldInterface)field, value, Type.BOOLEAN);
	}

	@Override
	public void onWriteAccess(byte value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
			txn.writeAccess((SMVFieldInterface)field, value, Type.BYTE);
	}

	@Override
	public void onWriteAccess(char value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
			txn.writeAccess((SMVFieldInterface)field, value, Type.CHAR);
	}

	@Override
	public void onWriteAccess(short value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
			txn.writeAccess((SMVFieldInterface)field, value, Type.SHORT);
	}

	@Override
	public void onWriteAccess(int value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
			txn.writeAccess((SMVFieldInterface)field, value, Type.INT);
	}

	@Override
	public void onWriteAccess(long value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
			txn.writeAccess((SMVFieldInterface)field, value, Type.LONG);
	}

	@Override
	public void onWriteAccess(float value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
			txn.writeAccess((SMVFieldInterface)field, value, Type.FLOAT);
	}

	@Override
	public void onWriteAccess(double value, TxField field) {
		if (!readWriteHint) {
			readWriteMarkers.insert(atomicBlockId, true);
			throw READ_ONLY_FAILURE_EXCEPTION;
		}
			txn.writeAccess((SMVFieldInterface)field, value, Type.DOUBLE);
	}

	public SMVAbstractTransaction getCurrentTxn() {
		return txn;
	}

}
