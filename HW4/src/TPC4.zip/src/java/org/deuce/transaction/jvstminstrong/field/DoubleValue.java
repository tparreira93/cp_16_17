package org.deuce.transaction.jvstminstrong.field;

public class DoubleValue implements Value {
	public double value;
}
