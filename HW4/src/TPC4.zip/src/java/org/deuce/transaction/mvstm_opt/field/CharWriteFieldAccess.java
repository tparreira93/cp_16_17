package org.deuce.transaction.mvstm_opt.field;

import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public class CharWriteFieldAccess extends WriteFieldAccess {

	public char value;

	public void set(char value, VBox field) {
		super.init(field);
		this.value = value;
	}

	@Override
	public void prepare() {
		((VBoxC)field).prepare(value);
	}

	public char getValue() {
		return value;
	}

}
