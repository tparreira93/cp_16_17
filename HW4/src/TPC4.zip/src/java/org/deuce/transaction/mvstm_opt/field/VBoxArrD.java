package org.deuce.transaction.mvstm_opt.field;

import org.deuce.reflection.AddressUtil;
import org.deuce.reflection.UnsafeHolder;
import org.deuce.transaction.mvstm_opt.LockTable;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxArrDoubleField;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public class VBoxArrD extends TxArrDoubleField implements VBoxD {
	public VersionD version;

	public VBoxArrD(double[] arr, int idx) {
	        super(arr, idx);
		version = new VersionD(0, super.readDouble(), null);
	}

	public boolean validate(Version version, int owner) {
		Version tmp = this.version;
		int l = lock;
		if ((l & LockTable.LOCK) != 0) {
			if ((l & LockTable.UNLOCK) != owner) {
				throw LockTable.LOCKED_VERSION_EXCEPTION;
			}
		}
		return tmp == version;
	}

	@Override
	public void prepare(double newValue) {
		VersionD ver = new VersionD(Integer.MAX_VALUE, newValue, version);
		this.version.value = super.readDouble();
		this.version = ver;
		write(ver.value);
	}

	@Override
	public void commit(int txNumber) {
		this.version.version = txNumber;
	}

	@Override
	public Version get(int version) {
		Version tmp = this.version;
		if ((lock & LockTable.LOCK) != 0) {
			throw LockTable.LOCKED_VERSION_EXCEPTION;
		}
		if (tmp.version > version) {
			throw LockTable.LOCKED_VERSION_EXCEPTION;
		}
		return tmp;
	}

	@Override
	public Version getRO(int version) {
		return this.version.get(version);
	}

	private static long __LOCK_FIELD__;
	static {
		try {
			__LOCK_FIELD__ = AddressUtil.getAddress(VBoxArrD.class.getDeclaredField("lock"));
		} catch (SecurityException e) {
		} catch (NoSuchFieldException e) {
		}
	}
	public volatile int lock = 0;
	
	@Override
	public boolean lock(int owner) {
		int l = lock;
		if ((l & LockTable.LOCK) != 0) {
			throw LockTable.LOCKED_VERSION_EXCEPTION;
		}
		if (!UnsafeHolder.getUnsafe().compareAndSwapInt(this, __LOCK_FIELD__, l, l | owner | LockTable.LOCK)) {
			throw LockTable.LOCKED_VERSION_EXCEPTION;
		}
		return true;
	}

	@Override
	public void unLock() {
		lock = 0;
	}

	@Override
	public Version getTop() {
		return version;
	}
}
