package org.deuce.transaction;

import java.util.concurrent.atomic.AtomicInteger;

import org.deuce.transform.ExcludeInternal;

@ExcludeInternal
public class StatsCollector {
	
	private static final int MAX_THREADS = Integer.getInteger("org.deuce.stats.maxthreads", 64);
	private static final AtomicInteger threadIdGen = new AtomicInteger(0);
	private static final int[] commits = new int[MAX_THREADS+10];
	private static final int[] explicitAborts = new int[MAX_THREADS+10];
	private static final int[] commitAborts = new int[MAX_THREADS+10];
	private static final int[] runningAborts = new int[MAX_THREADS+10];
	
	private int threadId;
	
	public StatsCollector() {
		this(threadIdGen.incrementAndGet());
	}
	
	public StatsCollector(int threadId) {
		this.threadId = threadId;
	}
	
	public void incCommit() {
		commits[threadId]++;
	}
	
	public void incExplicitAbort() {
		explicitAborts[threadId]++;
	}
	
	public void incCommitAbort() {
		commitAborts[threadId]++;
	}
	
	public void incRunningAbort() {
		runningAborts[threadId]++;
	}
	
	static {
		Runtime.getRuntime().addShutdownHook(new Thread() {
		    public void run() {
		    	int totalCommits = 0;
		    	int totalExplicitAborts = 0;
		    	int totalCommitAborts = 0;
		    	int totalRunningAborts = 0;
		    	for (int i=0; i <= MAX_THREADS; i++) {
		    		totalCommits += commits[i];
		    		totalExplicitAborts += explicitAborts[i];
		    		totalCommitAborts += commitAborts[i];
		    		totalRunningAborts += runningAborts[i];
		    	}
		    	System.out.println("\n@@@@@@@TotalCommits="+totalCommits);
		    	System.out.println("@@@@@@@TotalExplicitAborts="+totalExplicitAborts);
		    	System.out.println("@@@@@@@TotalRunningAborts="+totalRunningAborts);
		    	System.out.println("@@@@@@@TotalCommitAborts="+totalCommitAborts);
		    	System.out.println("@@@@@@@TotalAborts="+(totalCommitAborts+totalRunningAborts));
		    }
		});
	}
}
