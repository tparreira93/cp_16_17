package org.deuce.transaction.jvstminstrong.field;

public interface Value {

}
