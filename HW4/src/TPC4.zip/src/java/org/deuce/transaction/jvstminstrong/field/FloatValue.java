package org.deuce.transaction.jvstminstrong.field;

public class FloatValue implements Value {
	public float value;
}
