package org.deuce.transaction.jvstmlfadapter;

import jvstm.Transaction;
import jvstm.VBox;
import jvstm.WriteOnReadException;

import org.deuce.transaction.ContextDelegator;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxArrLongField;

@ExcludeInternal
public class VBoxArrL extends TxArrLongField implements VBoxAdapter {

	protected VBox<Object> vbox;
	
	public VBoxArrL(long[] arr, int idx) {
		super(arr, idx);
		try {
			vbox = new VBox<Object>((Long)Field.getValue(ref, address, Type.LONG));
		}
		catch (WriteOnReadException e) {
			((Context)ContextDelegator.getInstance()).readOnWriteException();
		}
	}

	@Override
	public VBox<Object> getVBox() {
		return vbox;
	}
	
	@Override
	public void write(long value) {
//		vbox.body.value = value;
		Transaction.current().setBoxValue(vbox, value);
	}
	@Override
	public long readLong() {
//		return (Long) vbox.body.value;
		return (Long) Transaction.current().getBoxValue(vbox);
	}
}
