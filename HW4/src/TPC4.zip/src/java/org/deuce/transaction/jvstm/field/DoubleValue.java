package org.deuce.transaction.jvstm.field;

public class DoubleValue implements Value {
	public double value;
}
