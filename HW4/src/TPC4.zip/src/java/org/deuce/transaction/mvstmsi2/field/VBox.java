package org.deuce.transaction.mvstmsi2.field;

import org.deuce.transaction.mvstmsi2.InPlaceLock;
import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public interface VBox extends InPlaceLock {
	boolean validate(Version version, int owner);
	Version get(int version);
	Version getTop();
}
