package org.deuce.transaction.jvstminstrong.field;

public class ByteValue implements Value {
	public byte value;
}
