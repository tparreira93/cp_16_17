package org.deuce.transaction.tl2cm.field;

import org.deuce.reflection.UnsafeHolder;
import org.deuce.transform.ExcludeInternal;

@ExcludeInternal
public class ObjectWriteFieldAccess extends WriteFieldAccess {

	private Object value;

	public void set(Object value, Object reference, long field) {
		super.init(reference, field);
		this.value = value;
	}
	
	@Override
	public void put() {
		UnsafeHolder.getUnsafe().putObject(reference, field, value);
		clear();
		value = null;
	}

	public Object getValue() {
		return value;
	}
}
