package org.deuce.transaction.mvstmsi2.field;

import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public interface VBoxD extends VBox {

	void commit(double value, int txNumber);

}
