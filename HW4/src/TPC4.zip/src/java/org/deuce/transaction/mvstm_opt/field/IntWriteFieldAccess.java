package org.deuce.transaction.mvstm_opt.field;

import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public class IntWriteFieldAccess extends WriteFieldAccess {

	public int value;

	public void set(int value, VBox field) {
		super.init(field);
		this.value = value;
	}

	@Override
	public void prepare() {
		((VBoxI)field).prepare(value);
	}

	public int getValue() {
		return value;
	}

}
