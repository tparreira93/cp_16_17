package org.deuce.transaction;

import org.deuce.objectweb.asm.Type;
import org.deuce.transform.ExcludeInternal;
import org.deuce.transform.inplacemetadata.type.TxField;

/**
 * All the STM implementations that use in-place metadata should implement this
 * interface and annotate the subclass with LocalMetadata annotation. Using the
 * -Dorg.deuce.transaction.contextClass property one can switch between the
 * different implementations.
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 * @author Tiago Vale <t.vale@campus.fct.unl.pt>
 */
@ExcludeInternal
public abstract class ContextMetadata extends StatsCollector implements IContext {
	final static public String NAME = Type.getInternalName(ContextMetadata.class);
	
	final static public String UUID_NONE_NAME = "UUID_NONE";
	final static public String UUID_NONE_DESC = Type.getDescriptor(Object.class);
	final static public Object UUID_NONE = new Object();
	
	final static public String UUID_NAME = "uuid";
	final static public String UUID_DESC = Type.getDescriptor(Object.class);
	public Object uuid = UUID_NONE;

	@Override
	public void init(int atomicBlockId, String metainf) {
		this.uuid = new Object();
		initImpl(atomicBlockId, metainf);
	}
	
	abstract protected void initImpl(int atomicBlockId, String metainf);
	
	/* Methods called on Read/Write event */
	abstract public void beforeReadAccess(TxField field);

	abstract public Object onReadAccess(Object value, TxField field);

	abstract public boolean onReadAccess(boolean value, TxField field);

	abstract public byte onReadAccess(byte value, TxField field);

	abstract public char onReadAccess(char value, TxField field);

	abstract public short onReadAccess(short value, TxField field);

	abstract public int onReadAccess(int value, TxField field);

	abstract public long onReadAccess(long value, TxField field);

	abstract public float onReadAccess(float value, TxField field);

	abstract public double onReadAccess(double value, TxField field);

	abstract public void onWriteAccess(Object value, TxField field);

	abstract public void onWriteAccess(boolean value, TxField field);

	abstract public void onWriteAccess(byte value, TxField field);

	abstract public void onWriteAccess(char value, TxField field);

	abstract public void onWriteAccess(short value, TxField field);

	abstract public void onWriteAccess(int value, TxField field);

	abstract public void onWriteAccess(long value, TxField field);

	abstract public void onWriteAccess(float value, TxField field);

	abstract public void onWriteAccess(double value, TxField field);

}
