package org.deuce.transaction.mvstm_opt.field;

import org.deuce.transaction.mvstm_opt.InPlaceLock;
import org.deuce.transform.ExcludeInternal;

/**
 * 
 * @author Ricardo Dias <ricardo.dias@campus.fct.unl.pt>
 */
@ExcludeInternal
public interface VBox extends InPlaceLock {
	boolean validate(Version version, int owner);
	Version get(int version);
	Version getRO(int version);
	Version getTop();
	
	void commit(int txNumber);
}
