package org.deuce;

import static java.lang.annotation.ElementType.TYPE;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation to specify the metadata classes for each type in an in-place
 * metadata algorithm.
 * 
 * @author Ricardo Dias, Tiago Vale <{ricardo.dias,t.vale}@campus.fct.unl.pt>
 */
@Target(TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface InPlaceMetadata {
	String fieldObjectClass() default "org.deuce.transform.inplacemetadata.type.TxObjectField";

	String fieldIntClass() default "org.deuce.transform.inplacemetadata.type.TxIntField";

	String fieldShortClass() default "org.deuce.transform.inplacemetadata.type.TxShortField";

	String fieldFloatClass() default "org.deuce.transform.inplacemetadata.type.TxFloatField";

	String fieldCharClass() default "org.deuce.transform.inplacemetadata.type.TxCharField";

	String fieldBooleanClass() default "org.deuce.transform.inplacemetadata.type.TxBooleanField";

	String fieldByteClass() default "org.deuce.transform.inplacemetadata.type.TxByteField";

	String fieldDoubleClass() default "org.deuce.transform.inplacemetadata.type.TxDoubleField";

	String fieldLongClass() default "org.deuce.transform.inplacemetadata.type.TxLongField";

	String arrayIntClass() default "org.deuce.transform.inplacemetadata.type.TxArrIntField";

	String arrayShortClass() default "org.deuce.transform.inplacemetadata.type.TxArrShortField";

	String arrayCharClass() default "org.deuce.transform.inplacemetadata.type.TxArrCharField";

	String arrayBooleanClass() default "org.deuce.transform.inplacemetadata.type.TxArrBoolField";

	String arrayByteClass() default "org.deuce.transform.inplacemetadata.type.TxArrByteField";

	String arrayFloatClass() default "org.deuce.transform.inplacemetadata.type.TxArrFloatField";

	String arrayLongClass() default "org.deuce.transform.inplacemetadata.type.TxArrLongField";

	String arrayDoubleClass() default "org.deuce.transform.inplacemetadata.type.TxArrDoubleField";

	String arrayObjectClass() default "org.deuce.transform.inplacemetadata.type.TxArrObjectField";
}
