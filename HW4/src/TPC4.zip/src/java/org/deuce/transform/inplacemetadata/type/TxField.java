package org.deuce.transform.inplacemetadata.type;

import org.deuce.objectweb.asm.Type;
import org.deuce.reflection.UnsafeHolder;
import org.deuce.transaction.ContextDelegator;
import org.deuce.transaction.ContextMetadata;
import org.deuce.transform.ExcludeInternal;

/**
 * In-place metadata class hierarchy.
 * 
 * @author Ricardo Dias, Tiago Vale <{ricardo.dias,t.vale}@campus.fct.unl.pt>
 */
@ExcludeInternal
public class TxField {
	final static public String NAME = Type.getInternalName(TxField.class);
	
	public Object ref;
	public final long address;
	final static public String CREATED_BY_NAME = "createdBy";
	final static public String CREATED_BY_DESC = Type.getDescriptor(Object.class);
	public final Object createdBy;

	public TxField(Object ref, long address) {
		this.ref = ref;
		this.address = address;
		this.createdBy = ((ContextMetadata) ContextDelegator.getInstance()).uuid;
	}
	
	public void write(Object value) {
		UnsafeHolder.getUnsafe().putObject(ref, address, value);
	}
	public void write(boolean value) {
		UnsafeHolder.getUnsafe().putBoolean(ref, address, value);
	}
	public void write(byte value) {
		UnsafeHolder.getUnsafe().putByte(ref, address, value);
	}
	public void write(char value) {
		UnsafeHolder.getUnsafe().putChar(ref, address, value);
	}
	public void write(short value) {
		UnsafeHolder.getUnsafe().putShort(ref, address, value);
	}
	public void write(int value) {
		UnsafeHolder.getUnsafe().putInt(ref, address, value);
	}
	public void write(long value) {
		UnsafeHolder.getUnsafe().putLong(ref, address, value);
	}
	public void write(float value) {
		UnsafeHolder.getUnsafe().putFloat(ref, address, value);
	}
	public void write(double value) {
		UnsafeHolder.getUnsafe().putDouble(ref, address, value);
	}
	
	public Object readObject() {
		return UnsafeHolder.getUnsafe().getObject(ref, address);
	}
	public boolean readBoolean() {
		return UnsafeHolder.getUnsafe().getBoolean(ref, address);
	}
	public byte readByte() {
		return UnsafeHolder.getUnsafe().getByte(ref, address);
	}
	public char readChar() {
		return UnsafeHolder.getUnsafe().getChar(ref, address);
	}
	public short readShort() {
		return UnsafeHolder.getUnsafe().getShort(ref, address);
	}
	public int readInt() {
		return UnsafeHolder.getUnsafe().getInt(ref, address);
	}
	public long readLong() {
		return UnsafeHolder.getUnsafe().getLong(ref, address);
	}
	public float readFloat() {
		return UnsafeHolder.getUnsafe().getFloat(ref, address);
	}
	public double readDouble() {
		return UnsafeHolder.getUnsafe().getDouble(ref, address);
	}
}
