package org.deuce.transform.inplacemetadata.type;

import org.deuce.reflection.AddressUtil;
import org.deuce.transform.ExcludeInternal;

/**
 * In-place metadata class hierarchy.
 * 
 * @author Ricardo Dias, Tiago Vale <{ricardo.dias,t.vale}@campus.fct.unl.pt>
 */
@ExcludeInternal
public class TxArrFloatField extends TxField {
	final static private int ARR_BASE = AddressUtil.arrayBaseOffset(float[].class);
	final static private int ARR_SCALE = AddressUtil.arrayIndexScale(float[].class);

	public float[] array;
	public int index;

	public TxArrFloatField(float[] arr, int idx) {
		super(arr, ARR_BASE + ARR_SCALE * idx);
		array = arr;
		index = idx;
	}
	
	public float readFloat() {
		return array[index];
	}

	public void write(float value) {
		array[index] = value;
	}
}
